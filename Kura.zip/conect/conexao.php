<?php
// Configurações do banco de dados
$host = "localhost";
$dbUsername = "id21191845_root";
$dbPassword = "Kuragan@12102005";
$dbName = "id21191845_kuragan";

// Criando a conexão usando a extensão MySQLi
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

// Verificando erros na conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

?>

<?php
session_start();

// Verifica se o cookie "lembrar_usuario_id" existe
if (isset($_COOKIE["lembrar_usuario_id"])) {
    $user_id = $_COOKIE["lembrar_usuario_id"];

    // Faça uma verificação adicional, se necessário, para garantir que o usuário com o ID do cookie seja válido

    // Autentica automaticamente o usuário
    $_SESSION["user_id"] = $user_id;
    // Defina outras informações de sessão, se necessário
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-adsense-account" content="ca-pub-8461031365208671">
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8461031365208671"
     crossorigin="anonymous"></script>
    <script async src="https://fundingchoicesmessages.google.com/i/pub-8461031365208671?ers=1" nonce="pmIeoapqgbfmXWsuLoIhiA"></script><script nonce="pmIeoapqgbfmXWsuLoIhiA">(function() {function signalGooglefcPresent() {if (!window.frames['googlefcPresent']) {if (document.body) {const iframe = document.createElement('iframe'); iframe.style = 'width: 0; height: 0; border: none; z-index: -1000; left: -1000px; top: -1000px;'; iframe.style.display = 'none'; iframe.name = 'googlefcPresent'; document.body.appendChild(iframe);} else {setTimeout(signalGooglefcPresent, 0);}}}signalGooglefcPresent();})();</script>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>


    <link rel="stylesheet" href="estilo/css/style.css">
    <?php
    // Obtém o valor da ação da URL
    $acao = isset($_GET['acao']) ? $_GET['acao'] : 'home';

    if ($acao === 'genero' or $acao === 'home' or $acao === 'busca') {
        echo '<link rel="stylesheet" href="estilo/css/genero.css">';
    }
    ?>
    
    <!-- Para a barra de endereços -->
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <!-- Para os favoritos -->
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <!-- Para a tela inicial de dispositivos móveis -->
    <link rel="icon" type="image/png" sizes="192x192" href="favicon-192x192.png">
    
    <!--<script src="chat/estilo/script.js"></script>-->

    <title>kuragan</title>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark bg-personalized">
            <a class="navbar-brand"
                style="position: relative; width: 150px; height: 40px; display: flex; align-items: center;justify-content: center;"
                href="index.php?acao=home"><img style="width:100%; height:100%; object-fit:cover; position: absolute;"
                    src="logo.png" alt=""></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">

                    <?php

                    $linkuser = "";
                    $notification = "";

                    if (isset($_SESSION["user_id"])) {
                        // Usuário está logado
                        include_once 'conect/conexao.php';

                        $user_id = $_SESSION["user_id"];
                        $sql = "SELECT tipo_user, username, foto FROM tb_user WHERE user_id = $user_id";
                        $result = $conn->query($sql);

                        if ($result->num_rows == 1) {
                            $row = $result->fetch_assoc();
                            $user_name = $row["username"];
                            $user_photo = 'assets/user/' . $row["foto"]; // Substitua pelo caminho real da foto
                            $user_type = $row["tipo_user"]; // Tipo de usuário
                    
                            echo '<div class="nav-item dropdown">';
                            echo '<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">';
                            echo '<img src="' . $user_photo . '" alt="Foto do Usuário" class="rounded-circle" width="30" height="30"> ' . $user_name;
                            echo '</a>';
                            echo '<div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">';
                            echo '<a class="dropdown-item" href="index.php?acao=user">Perfil</a>';
                            if($user_type == 3){
                            echo '<div class="dropdown-divider"></div>';
                            echo '<a class="dropdown-item" href="adm/index.php">adm</a>';
                            }
                            echo '<div class="dropdown-divider"></div>';
                            echo '<a class="dropdown-item" href="logout.php">Sair</a>';
                            
                            echo '</div>';
                            echo '</div>';

                            $notification = '<a class="nav-link" href="index.php?acao=notif">
                            <i class="fas fa-bell"></i> <!-- Ícone de notificação -->
                        </a>
                        <a class="nav-link" href="area-chat/index.php?acao=home">
                            <i class="fas fa-envelope"></i> Chat Privado
                        </a>';

                        } else {
                            // Lidar com erro (não encontrou usuário)
                        }

                    } else {
                        // Usuário não está logado
                    
                        echo '<a class="nav-link" href="login.php">Login</a>';
                        echo '<a class="nav-link" href="index.php?acao=cadastro">Cadastro</a>';

                    }

                    echo '<a class="nav-link" href="index.php">Home</a>';
                    echo '<a class="nav-link" href="index.php?acao=sobre">Sobre</a>';

                    // Faz a conexão com o banco de dados
                    include('conect/conexao.php');

                    // Faz um SELECT na tabela tb_genero para obter os gêneros
                    $sql_generos = "SELECT * FROM tb_genero";
                    $result_generos = $conn->query($sql_generos);

                    $generos = array();
                    while ($row = $result_generos->fetch_assoc()) {
                        $generos[] = $row['nome_genero'];
                    }

                    echo '<div class="nav-item dropdown">';
                    echo '<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">';
                    echo 'Gêneros';
                    echo '</a>';
                    echo '<div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">';
                    echo '<a class="dropdown-item" href="index.php?acao=genero&allview=todos os gêneros">Todos os Gêneros</a>';
                    echo '<div class="dropdown-divider"></div>';

                    foreach ($generos as $genero) {
                        echo '<a class="dropdown-item" href="index.php?acao=genero&genre=' . urlencode($genero) . '">' . $genero . '</a>';
                        echo '<div class="dropdown-divider"></div>';
                    }

                    echo '</div>';
                    echo '</div>';

                    echo '<a class="nav-link" href="index.php?acao=chat">Chat</a>';
                    echo '<a class="nav-link" href="index.php?acao=suporte">Suporte</a>';
                    echo $notification;
                    ?>
                    <!-- Campo de pesquisa -->
                    <li class="nav-item">
                        <form class="form-inline my-2 my-lg-0" action="index.php?acao=busca" method="post">
                            <div class="input-group">
                                <input type="text" class="form-control rounded-pill border-0 bg-light control-imb"
                                    name="search" placeholder="Pesquisar filmes" aria-label="Pesquisar filmes"
                                    aria-describedby="botao-pesquisar">
                                <div class="input-group-append">
                                    <button class="btn btn-outline-secondary rounded-circle secondary-imb" type="submit"
                                        id="botao-pesquisar"><i class="fas fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </li>

                </ul>
            </div>
        </nav>

    </header>
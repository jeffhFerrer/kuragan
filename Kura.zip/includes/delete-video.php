<?php
include('conect/conexao.php');
if ($_GET['acao'] == 'delete-filme') {
    $video_id = $_GET['video_id'];

    // Consulta para obter informações sobre o vídeo
    $sql_get_video = "SELECT * FROM tb_video WHERE video_id = $video_id";
    $result_get_video = $conn->query($sql_get_video);

    if ($result_get_video->num_rows > 0) {
        $row_video = $result_get_video->fetch_assoc();

        // Excluir registros na tabela tb_coment que estão relacionados ao vídeo
        $sql_delete_coments = "DELETE FROM tb_coment WHERE video_id = $video_id";
        $conn->query($sql_delete_coments);

        // Excluir registros na tabela tb_visualizacoes que estão relacionados ao vídeo
        $sql_delete_visualizacoes = "DELETE FROM tb_visualizacoes WHERE video_id = $video_id";
        $conn->query($sql_delete_visualizacoes);

        // Exclua os arquivos físicos (caso existam)
        if (!empty($row_video['capa']) && file_exists($row_video['capa'])) {
            unlink($row_video['capa']);
        }

        if (!empty($row_video['posts']) && file_exists($row_video['posts'])) {
            unlink($row_video['posts']);
        }

        if (!empty($row_video['url']) && strpos($row_video['url'], 'uploads/') === 0 && file_exists($row_video['url'])) {
            unlink($row_video['url']);
        }

        // Excluir o registro na tabela tb_video
        $sql_delete_video = "DELETE FROM tb_video WHERE video_id = $video_id";
        $conn->query($sql_delete_video);

        // Redirecionar de volta para a página de listagem de vídeos
        header("Location: index.php?acao=acao-videos");
        exit();
    } else {
        echo '<div id="no-sucess">Vídeo não encontrado</div>';
    }
} else {
    echo '<div id="no-sucess">ID do vídeo não fornecido.</div>';
}
?>
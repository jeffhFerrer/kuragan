<div class="footer">
    <div class="footer-logo">kuragan</div>

    <div class="footer-links">
        <a href="index.php">Página Inicial</a>
        <a href="index.php?acao=sobre">Sobre Nós</a>
        <a href="index.php?acao=suporte">Suporte</a>
    </div>

    <div class="footer-social">
        <a href="#" target="_blank"><i class="fab fa-facebook"></i></a>
        <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
        <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
    </div>

    <p>&copy; 2023 kuragan. Todos os direitos reservados.</p>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
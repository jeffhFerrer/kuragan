<?php
// Conexão com o banco de dados
include_once 'conect/conexao.php';
// Suponha que você tenha uma sessão de usuário ativa com o ID do usuário
$user_id = $_SESSION['user_id'];

// Consulta para buscar os dados do usuário
$sql = "SELECT * FROM `tb_user` WHERE `user_id` = $user_id";
$result = mysqli_query($conn, $sql);

if ($result) {
    $row = mysqli_fetch_assoc($result);
}
?>

<style>
    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 10px;
    }

    .card {
        background: #7777771b;
        color: #fff;
        padding: 20px;
        border-radius: 10px;
        display: flex;
        align-items: center;
    }

    .card img {
        width: 100px;
        height: 100px;
        border-radius: 100%;
        margin-right: 20px;
        object-fit: cover;
    }

    .card-info {
        flex: 1;
        text-align: center;
    }

    .dropdown-user {
        position: relative;
        display: inline-block;
        margin-top: 10px;
        width: 200px;
    }

    .dropdown-toggle-user {
        width: 100%;
        background: linear-gradient(to bottom right, rgba(45, 202, 74, 0.5), rgba(5, 157, 199, 0.5), rgba(40, 192, 83, 0.5));
        color: #fff;
        font-weight: 900;
        border: none;
        padding: 8px 12px;
        cursor: pointer;
        border-radius: 5px;
        outline: none !important;
    }

    .dropdown-user:hover .dropdown-menu-user {
        display: block;
        background: #fff;
    }

    .dropdown-menu-user {
        width: 100%;
        position: absolute;
        background-color: #333;
        color: #fff;
        border: none;
        border-radius: 5px;
        padding: 10px;
        right: 0;
        display: none;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
    }

    .dropdown-user:hover .dropdown-menu-user {
        display: block;
    }

    .dropdown-menu-user a {
        border-bottom: 1px solid #777;
        display: block;
        padding: 5px 0;
        color: #000924;
        font-weight: 900;
        text-decoration: none;
        transition: background-color 0.3s ease-in-out;
    }

    .dropdown-menu-user a:hover {
        background-color: #5555551b;
    }

    /* Estilos para a área de histórico */
    .history-list {
        list-style: none;
        padding: 0;
    }

    .history-list li {
        display: flex;
        align-items: center;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 5px;
    }

    .history-list a {
        text-decoration: none;
        color: #999;
        display: flex;
        align-items: center;
        width: 100%;
    }

    .history-list img {
        max-width: 100px;
        height: auto;
        border-radius: 5px;
        margin-right: 10px;
    }

    .history-list .info {
        flex: 1;
    }

    .history-list .info h3 {
        margin: 0;
        margin-bottom: 5px;
    }

    .history-list .info span {
        display: block;
    }
</style>

<?php
// Suponha que você tenha uma sessão de usuário ativa com o ID do usuário
$user_id = $_SESSION['user_id'];

// Consulta para buscar os dados do usuário
$sql_user = "SELECT * FROM tb_user WHERE user_id = $user_id";
$result_user = mysqli_query($conn, $sql_user);

if ($result_user) {
    $row_user = mysqli_fetch_assoc($result_user);
}

// Defina os links de acordo com o tipo de usuário
$linkuser = ''; // Inicializa a variável de links vazia

if ($row_user['tipo_user'] == 2) {
    // User auxiliar
    $linkuser .= '<a class="nav-link" href="index.php?acao=upload">Upload</a>
    <a class="nav-link" href="index.php?acao=suporte_reg">Suporte</a>
                <a href="index.php?acao=acao-videos">Ações</a>';
} elseif ($row_user['tipo_user'] == 3) {
    // Super user (admin)
    $linkuser .= '<a class="nav-link" href="index.php?acao=type_user">Tipe User</a>
                <a class="nav-link" href="index.php?acao=upload">Upload</a>
                <a href="index.php?acao=acao-videos">Ações</a>
                <a href="index.php?acao=notification">Notificação</a>
                <a class="nav-link" href="index.php?acao=suporte_reg">Suporte</a>
                <a class="nav-link" href="index.php?acao=logs">Acessos</a>';
    // Adicione outros links de acesso específicos para o super user aqui
}

?>

<div class="container">
    <div class="card">
        <img src="assets/user/<?php echo $row['foto']; ?>" alt="Foto de Perfil">
        <div class="card-info">
            <h2>
                <?php echo $row['username']; ?>
            </h2>
            <input
                style="width: 150px; text-align: center; border:1px solid #fff; border-radius:10px; outline: none; background: transparent; color: #fff;"
                type="text" id="chaveUnica" value="<?php echo $row['chave_unica']; ?>" readonly>
            <button onclick="copiarChave()" style="border-radius:100%;"><i class="fas fa-copy"></i></button>

            <script>
                function copiarChave() {
                    var chaveInput = document.getElementById('chaveUnica');
                    chaveInput.select();
                    document.execCommand('copy');
                    alert('Chave copiada para a área de transferência.');
                }
            </script>
            <p>
                <?php
                // Supondo que $row['data_nascimento'] contenha "12/10/2005"
                $dateParts = explode("/", $row['data_nascimento']); // Divide a data em partes
                if (count($dateParts) === 3) {
                    $formattedDate = $dateParts[2] . '-' . $dateParts[1] . '-' . $dateParts[0]; // Formata para "YYYY-MM-DD"
                    echo 'Data de Nascimento:' . date("d/m/Y", strtotime($formattedDate)); // Exibe no formato "DD/MM/YYYY"
                } else {
                    echo "Data de nascimento inválida"; // Lida com datas inválidas
                }
                ?>
            </p>
            <div class="dropdown-user">
                <button class="dropdown-toggle-user">Opções</button>
                <div class="dropdown-menu-user">
                    <a href="index.php?acao=upuser">Editar Perfil</a>
                    <?php echo $linkuser ?>
                </div>
            </div>
        </div>
    </div>
    <h2 style="margin-top: 20px; background: #7777771b; padding:10px; border-radius:7px;">Histórico de Filmes Assistidos
    </h2>
    <?php
    // Suponha que você tenha uma sessão de usuário ativa com o ID do usuário
    $user_id = $_SESSION['user_id'];

    // Substitua esta linha pela sua consulta SQL para buscar o histórico de filmes assistidos
    $sql_movies = "SELECT v.`video_id`, v.`title`, v.`url`, v.`capa`, vu.`data_visualizacao`
               FROM `tb_video` AS v
               JOIN `tb_visualizacoes` AS vu ON v.`video_id` = vu.`video_id`
               WHERE vu.`user_id` = $user_id
               ORDER BY vu.`data_visualizacao` DESC";

    $result_movies = mysqli_query($conn, $sql_movies);

    $movies = [];
    if ($result_movies) {
        while ($row_movie = mysqli_fetch_assoc($result_movies)) {
            $movies[] = $row_movie;
        }
    }

    ?>

    <ul class="history-list">
        <?php foreach ($movies as $movie) { ?>
            <li>
                <a href="index.php?acao=video&video_id=<?php echo $movie['video_id']; ?>">
                    <img src="<?php echo $movie['capa']; ?>" alt="<?php echo $movie['title']; ?>">
                    <div class="info">
                        <h3>
                            <?php echo $movie['title']; ?>
                        </h3>
                        <span>Ultima Visualização:
                            <?php echo date('d/m/Y H:i:s', strtotime($movie['data_visualizacao'])); ?>
                        </span>
                    </div>
                </a>
            </li>
        <?php } ?>
    </ul>
</div>
</div>
<style>
    /* Coloque os estilos CSS aqui */

    /* Estilos para o formulário de edição de perfil */
    .edit-form {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background-color: #7777771b;
        margin: 20px;
        color: #fff;
        font-weight: 900;
        border-radius: 10px;
    }

    .edit-form label {
        display: block;
        margin-bottom: 10px;
    }

    .edit-form input {
        width: 100%;
        padding: 8px;
        margin-bottom: 15px;
        font-weight: 900;
    }

    .edit-form button {
        background-color: #fff;
        color: #000924;
        font-weight: 900;
        border: none;
        padding: 8px 12px;
        border-radius: 5px;
        cursor: pointer;
    }
</style>

<?php
include_once 'conect/conexao.php';

$user_id = $_SESSION['user_id'];

// Consulta para buscar os dados do usuário
$sql = "SELECT * FROM `tb_user` WHERE `user_id` = $user_id";
$result = mysqli_query($conn, $sql);

if ($result) {
    $row = mysqli_fetch_assoc($result);
}

if (isset($_POST['atualizar_perfil'])) {
    $new_username = $_POST['username'];
    $new_email = $_POST['email'];
    $new_data_nascimento = $_POST['data_nascimento'];
    $new_senha = $_POST['senha'];

    // Verificar se o usuário alterou a imagem de perfil
    if (!empty($_FILES['foto']['name'])) {
        // Verificar se a foto antiga existe e excluir
        if (!empty($row['foto'])) {
            $foto_antiga = 'assets/user/' . $row['foto'];
            if (file_exists($foto_antiga)) {
                unlink($foto_antiga);
            }
        }

        // Lidar com o upload da nova imagem de perfil
        $nome_da_nova_imagem = $_FILES['foto']['name'];
        $caminho_da_nova_imagem = 'assets/user/' . $nome_da_nova_imagem;

        if (move_uploaded_file($_FILES['foto']['tmp_name'], $caminho_da_nova_imagem)) {
            // Atualizar apenas a foto do perfil no banco de dados
            $sql_update_foto = "UPDATE `tb_user` SET `foto` = '$nome_da_nova_imagem' WHERE `user_id` = $user_id";
            $result_update_foto = mysqli_query($conn, $sql_update_foto);

            if ($result_update_foto) {
                // Foto de perfil atualizada com sucesso
                echo '<script>window.location.href = "index.php?acao=user";</script>';
                exit();
            } else {
                // Erro ao atualizar a foto de perfil
                echo '<div id="no-sucess">Erro ao atualizar a foto de perfil. Por favor, tente novamente.</div>';
            }
        } else {
            echo '<div id="no-sucess">Erro ao fazer upload da imagem.</div>';
            exit();
        }
    }

    // Atualizar os campos do usuário no banco de dados, apenas se eles estiverem preenchidos
    $update_fields = array();
    if (!empty($new_username)) {
        $update_fields[] = "`username` = '$new_username'";
    }
    if (!empty($new_email)) {
        $update_fields[] = "`email` = '$new_email'";
    }
    if (!empty($new_data_nascimento)) {
        $update_fields[] = "`data_nascimento` = '$new_data_nascimento'";
    }
    if (!empty($new_senha)) {
        $new_senha = password_hash($new_senha, PASSWORD_DEFAULT);
        $update_fields[] = "`senha` = '$new_senha'";
    }

    if (!empty($update_fields)) {
        // Montar a query SQL para atualizar os campos selecionados
        $update_query = "UPDATE `tb_user` SET " . implode(", ", $update_fields) . " WHERE `user_id` = $user_id";

        $result_update = mysqli_query($conn, $update_query);

        if ($result_update) {
            // Atualização bem-sucedida
            if ($new_username !== $_SESSION['username']) {
                $_SESSION['username'] = $new_username;
            }
            echo '<script>window.location.href = "index.php?acao=user";</script>';
            exit();
        } else {
            // Erro na atualização
            echo '<div id="no-sucess">Erro ao atualizar o perfil. Por favor, tente novamente.</div>';
        }
    }
}
?>

<div class="edit-form">
    <h2>Editar Perfil</h2>
    <form action="" method="post" enctype="multipart/form-data">
        <label for="username">Nome de Usuário:</label>
        <input type="text" id="username" name="username" value="<?php echo $row['username']; ?>">

        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email" value="<?php echo $row['email']; ?>">

        <label for="senha">Nova Senha:</label>
        <input type="password" id="senha" name="senha" minlength="6" maxlength="20">

        <label for="data_nascimento">Data de Nascimento:</label>
        <input type="text" id="data_nascimento" name="data_nascimento"
            value="<?php echo date('d/m/Y', strtotime($row['data_nascimento'])); ?>">

        <!-- Corrigido o nome do campo para "foto" -->
        <label for="foto">Foto de Perfil:</label>
        <input type="file" style="border: 1px solid #fff; border-radius: 5px;" id="foto" name="foto">

        <button type="submit" name="atualizar_perfil">Salvar Alterações</button>
    </form>
</div>
<style>
    .container {
        margin-top: 30px;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    }

    .table-header {
        width: 100%;
        border-collapse: collapse;
    }

    .table-header th {
        border: 1px solid #ddd;
        padding: 8px;
        background-color: #007bff;
        color: #fff;
        text-align: left;
    }

    .table-header td {
        border: 1px solid #ddd;
        padding: 8px;
    }

    h1 {
        font-size: 24px;
        margin-top: 20px;
    }

    .mensagem {
        font-size: 16px;
        margin-top: 10px;
    }

    img {
        max-width: 100%;
        height: auto;
    }
</style>
</head>

<body>
    <div class="container">
        <h1>Detalhes do Registro</h1>
        <table class="table-header">
            <?php
            // Inclua o arquivo de conexão com o banco de dados aqui
            include_once('conect/conexao.php');

            // Verifique se o parâmetro 'id' foi fornecido na URL
            if (isset($_GET['id'])) {
                // Obtenha o valor do parâmetro 'id'
                $id = $_GET['id'];

                // Consulta SQL para obter os detalhes do registro com base no ID
                $sql = "SELECT nome, email, assunto FROM mensagens_suporte WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $result = $stmt->get_result();

                // Verifique se o registro foi encontrado
                if ($result->num_rows > 0) {
                    $registro = $result->fetch_assoc();
                    echo '<tr><th>Nome:</th><td>' . $registro['nome'] . '</td></tr>';
                    echo '<tr><th>Email:</th><td>' . $registro['email'] . '</td></tr>';
                    echo '<tr><th>Assunto:</th><td>' . $registro['assunto'] . '</td></tr>';
                }
            }
            ?>
        </table>
    </div>

    <div class="container mt-3">
        <?php
        // Verifique se o parâmetro 'id' foi fornecido na URL
        if (isset($_GET['id'])) {
            // Obtenha o valor do parâmetro 'id'
            $id = $_GET['id'];

            // Consulta SQL para obter os detalhes do registro com base no ID
            $sql = "SELECT mensagem, imagem FROM mensagens_suporte WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();

            // Verifique se o registro foi encontrado
            if ($result->num_rows > 0) {
                $registro = $result->fetch_assoc();
                echo '<div class="mensagem">' . $registro['mensagem'] . '</div>';

                // Verifique se há uma imagem associada ao registro
                if ($registro['imagem'] == 'suporte/') {

                } else {
                    echo '<img src="' . $registro['imagem'] . '" alt="Imagem">';
                }
            }
        }
        ?>
    </div>
<main class="container my-4">
    <h2 class="mb-4">Upload e informações de Vídeos</h2>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="video">Vídeo:</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="video" name="video" accept="video/*" required>
                <label class="custom-file-label" for="video">Escolha um arquivo de vídeo</label>
            </div>
        </div>
        <div class="form-group">
            <label for="capa">Capa do Vídeo:</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="capa" name="capa" accept="image/*" required>
                <label class="custom-file-label" for="capa">Escolha um arquivo de imagem</label>
            </div>
        </div>

        <div class="form-group">
            <label for="classificacao">Classificação Indicativa:</label>
            <select class="form-control" id="classificacao" name="classificacao" required>
                <option value="">Selecione a classificação indicativa</option>
                <option value="Livre">Livre</option>
                <option value="10+">10+</option>
                <option value="12+">12+</option>
                <option value="14+">14+</option>
                <option value="16+">16+</option>
                <option value="18+">18+</option>
            </select>
        </div>


        <div class="form-group">
            <label for="titulo">Título:</label>
            <input type="text" class="form-control" name="titulo" required>
        </div>

        <div class="form-group">
            <label for="descricao">Descrição:</label>
            <textarea class="form-control" name="descricao" rows="4" required></textarea>
        </div>

        <div class="form-group">
            <label for="genero">Gênero:</label>
            <input type="text" class="form-control" name="genero" required>
        </div>

        <button type="submit" class="btn btn-primary" name="submit">Enviar Vídeo</button>
    </form>
    <?php
    include_once('conect/conexao.php');

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
        $titulo = cleanInput($_POST["titulo"]);
        $descricao = cleanInput($_POST["descricao"]);
        $genero = cleanInput($_POST["genero"]);
        $classificacao = cleanInput($_POST["classificacao"]);

        // ... (validações e preparação de dados)
    
        $capaName = generateUniqueFileName($_FILES["capa"]["name"]);
        $capaTmp = $_FILES["capa"]["tmp_name"];

        $capaExtension = strtolower(pathinfo($capaName, PATHINFO_EXTENSION));
        $allowedImageExtensions = array("jpg", "jpeg", "png", "gif");

        if (in_array($capaExtension, $allowedImageExtensions)) {
            $uploadCapaPath = "assets/video/capa/" . $capaName;
            if (move_uploaded_file($capaTmp, $uploadCapaPath)) {
                $videoName = generateUniqueFileName($_FILES["video"]["name"]);
                $videoTmp = $_FILES["video"]["tmp_name"];

                $videoExtension = strtolower(pathinfo($videoName, PATHINFO_EXTENSION));
                $allowedVideoExtensions = array("mp4", "avi", "mov");

                if (in_array($videoExtension, $allowedVideoExtensions)) {
                    $uploadVideoPath = "uploads/" . $videoName;
                    if (move_uploaded_file($videoTmp, $uploadVideoPath)) {
                        
                        $dataHoraAtual = date("Y-m-d H:i:s"); // Definir data e hora atual
                        // Preparar e executar a consulta apenas se ambos os uploads forem bem-sucedidos
                
                        $sql = "INSERT INTO tb_video (title, url, descricao, data_publicacao, classificacao, genero, capa)
                                VALUES (?, ?, ?, ?, ?, ?, ?)";

                        $stmt = $conn->prepare($sql);
                        if (!$stmt) {
                            die('Erro na preparação da consulta: ' . $conn->error);
                        }

                        $stmt->bind_param("sssssss", $titulo, $uploadVideoPath, $descricao, $dataHoraAtual, $classificacao, $genero, $uploadCapaPath);

                        if ($stmt->execute()) {
                            echo "Vídeo, imagem da capa e informações enviados com sucesso!";
                        } else {
                            echo "Erro ao enviar o vídeo, imagem da capa e informações.";
                        }

                        $stmt->close();
                    } else {
                        echo "Erro ao carregar o vídeo.";
                    }
                } else {
                    echo "Formato de vídeo não suportado. Apenas formatos MP4, AVI e MOV são permitidos.";
                }
            } else {
                echo "Erro ao carregar a imagem da capa.";
            }
        } else {
            echo "Formato de imagem não suportado. Apenas formatos JPG, JPEG, PNG e GIF são permitidos.";
        }
    }

    // Fechamento da conexão com o banco de dados
    $conn->close();

    function cleanInput($input)
    {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input);
        return $input;
    }

    function generateUniqueFileName($originalName)
    {
        $extension = pathinfo($originalName, PATHINFO_EXTENSION);
        $newName = uniqid() . '.' . $extension;
        return $newName;
    }
    ?>
</main>
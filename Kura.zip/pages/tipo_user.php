<?php
include_once('conect/conexao.php');

// Verificar se o tipo de usuário não está definido ou é diferente de 2 ou 3
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Consulta para buscar os dados do usuário
    $sql_user = "SELECT * FROM tb_user WHERE user_id = $user_id";
    $result_user = mysqli_query($conn, $sql_user);

    if ($result_user && mysqli_num_rows($result_user) > 0) {
        $row_user = mysqli_fetch_assoc($result_user);

        if (!isset($row_user['tipo_user']) || ($row_user['tipo_user'] != 2 && $row_user['tipo_user'] != 3)) {
            // Redirecionar o usuário para a página de índice
            echo '<script>
            setTimeout(function() {
                window.location.href = "index.php";
            }, 0000); 
            </script>';

            exit();
        }
    } else {
        // Usuário não encontrado
        // Redirecionar para a página de índice ou exibir uma mensagem de erro
        echo '<script>
        setTimeout(function() {
            window.location.href = "index.php";
        }, 0000); 
        </script>';
        exit();
    }
} else {
    // Sessão não definida (usuário não está logado)
    // Redirecionar para a página de índice ou exibir uma mensagem de erro
    echo '<script>
    setTimeout(function() {
        window.location.href = "index.php";
    }, 0000); 
    </script>';
    exit();
}

// Inicialize as variáveis
$filter = '';
$nameFilter = '';
$emailFilter = '';

// Verifique se o formulário foi enviado
if (isset($_POST["filtragem"])) {
    // Verificar se as variáveis de filtro estão definidas via POST
    if (isset($_POST["user_type"])) {
        $filter = $_POST["user_type"];
    }

    if (isset($_POST["user_name"])) {
        $nameFilter = $_POST["user_name"];
    }

    if (isset($_POST["user_email"])) {
        $emailFilter = $_POST["user_email"];
    }
}

// Construir a consulta SQL com base nas variáveis de filtro
$sql = "SELECT * FROM tb_user WHERE 1"; // Inicializa a consulta com um valor verdadeiro

if (!empty($filter)) {
    $sql .= " AND tipo_user = $filter";
}

if (!empty($nameFilter)) {
    $sql .= " AND username LIKE '%$nameFilter%'";
}

if (!empty($emailFilter)) {
    $sql .= " AND email LIKE '%$emailFilter%'";
}
?>
<style>
    table {
        color: #fff !important;
        margin-top: 20px;
    }

    table td {
        vertical-align: middle;
        text-align: center;
        color: #fff;
    }
</style>
<div class="container">
    <!-- Formulário de Filtragem -->
    <form method="post" action="">
        <div class="row g-3">
            <div class="col-md-3">
                <label for="filter" class="form-label">Filtrar por tipo de usuário:</label>
                <select name="user_type" id="filter" class="form-select">
                    <option value="">Todos</option>
                    <option value="1">Tipo 1</option>
                    <option value="2">Tipo 2</option>
                    <option value="3">Tipo 3</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="name" class="form-label">Nome:</label>
                <input type="text" name="user_name" id="name" class="form-control">
            </div>
            <div class="col-md-3">
                <label for="email" class="form-label">Email:</label>
                <input type="text" name="user_email" id="email" class="form-control">
            </div>
            <div class="col-md-3">
                <label for="submit" class="form-label">&nbsp;</label>
                <input name="filtragem" type="submit" value="Filtrar" class="btn btn-primary form-control">
            </div>
        </div>
    </form>

    <!-- Tabela de Usuários -->
    <?php
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo '<div class="table-responsive">';
        echo '<table class="table table-bordered table-striped">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Nome</th>';
        echo '<th>Email</th>';
        echo '<th>T.U</th>';
        echo '<th>Ações</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row['username'] . '</td>';
            echo '<td>' . $row['email'] . '</td>';
            echo '<td>' . $row['tipo_user'] . '</td>';
            echo '<td>';
            echo '<form method="post" action="" style="display:flex; align-items:center; justify-content: center;">';
            echo '<input type="hidden" name="user_id" value="' . $row['user_id'] . '">';
            echo '<button type="submit" name="elevar_usuario" class="btn btn-success" style="display:flex; align-items:center; justify-content: center; margin-right:2px; width: 30px; height:30px;"><i class="fas fa-level-up-alt" style="font-size: 10px;"></i></button>';
            echo '<button type="submit" name="rebaixar_usuario" class="btn btn-danger" style="display:flex; align-items:center; justify-content: center; margin-left:2px;width: 30px; height:30px;"><i class="fas fa-level-down-alt" style="font-size: 10px;"></i></button>';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
        echo '</div>';
    } else {
        echo 'Nenhum usuário encontrado.';
    }
    if (isset($_POST["elevar_usuario"])) {
        // Processar a ação de elevar usuário
        $userId = $_POST["user_id"];

        // Verificar o tipo atual do usuário
        $sqlGetUserType = "SELECT tipo_user FROM tb_user WHERE user_id = $userId";
        $resultUserType = $conn->query($sqlGetUserType);

        if ($resultUserType->num_rows > 0) {
            $rowUserType = $resultUserType->fetch_assoc();
            $currentType = $rowUserType["tipo_user"];

            // Verificar se o usuário pode ser elevado (por exemplo, de 1 para 2)
            if ($currentType < 3) {
                $newType = $currentType + 1;

                // Execute uma consulta SQL UPDATE para atualizar o tipo de usuário
                $sqlUpdate = "UPDATE tb_user SET tipo_user = $newType WHERE user_id = $userId";
                if ($conn->query($sqlUpdate) === TRUE) {
                    echo "Usuário elevado com sucesso.";
                    echo '<script>
                        setTimeout(function() {
                            window.location.href = "index.php?acao=type_user";
                        }, 0000); 
                    </script>';
                } else {
                    echo "Erro ao elevar o usuário: " . $conn->error;
                }
            } else {
                echo "O usuário já possui o nível máximo.";
            }
        } else {
            echo "Usuário não encontrado.";
        }
    } elseif (isset($_POST["rebaixar_usuario"])) {
        // Processar a ação de rebaixar usuário
        $userId = $_POST["user_id"];

        // Verificar o tipo atual do usuário
        $sqlGetUserType = "SELECT tipo_user FROM tb_user WHERE user_id = $userId";
        $resultUserType = $conn->query($sqlGetUserType);

        if ($resultUserType->num_rows > 0) {
            $rowUserType = $resultUserType->fetch_assoc();
            $currentType = $rowUserType["tipo_user"];

            // Verificar se o usuário pode ser rebaixado (por exemplo, de 3 para 2)
            if ($currentType > 1) {
                $newType = $currentType - 1;

                // Execute uma consulta SQL UPDATE para atualizar o tipo de usuário
                $sqlUpdate = "UPDATE tb_user SET tipo_user = $newType WHERE user_id = $userId";
                if ($conn->query($sqlUpdate) === TRUE) {
                    echo "Usuário rebaixado com sucesso.";
                    echo '<script>
                        setTimeout(function() {
                            window.location.href = "index.php?acao=type_user";
                        }, 0000); 
                    </script>';
                } else {
                    echo "Erro ao rebaixar o usuário: " . $conn->error;
                }
            } else {
                echo "O usuário já possui o nível mínimo.";
            }
        } else {
            echo "Usuário não encontrado.";
        }
    }

    ?>
</div>
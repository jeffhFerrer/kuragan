<main>
    <?php
    // Faz a conexão com o banco de dados
    include('conect/conexao.php');

    // Faz um SELECT na tabela tb_video para obter os dados dos vídeos
    $sql = "SELECT * FROM tb_video ORDER BY video_id DESC LIMIT 10";
    $result = $conn->query($sql);
    ?>

    <style>
        .row {
            width: 100%;
            padding: 5px 0 5px 0;
            margin: 0 !important;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            padding-bottom: 0 !important;
        }

        .movie-card {
            margin-bottom: 0 !important;
        }
        .title-banner{
            position: absolute;
            bottom: 50px;
            left: 0;
            padding: 10px;
            background: #111111b1;
            width: 100%;
            display: flex;
            align-items: center;
            color: #fff;
            text-transform: uppercase;
            font-weight: 700;
            z-index:20;
        }
        .title-banner:hover{
            color:#ccc;
            text-decoration:none;
        }
    </style>
    <div class="container">
        <div id="movieCarousel" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <?php
                $indicatorIndex = 0;
                // Loop para criar os indicadores de slides
                while ($row = $result->fetch_assoc()) {
                    $indicatorClass = ($indicatorIndex == 0) ? 'class="active"' : '';
                    echo "<li data-target='#movieCarousel' data-slide-to='$indicatorIndex' $indicatorClass></li>";
                    $indicatorIndex++;
                }
                ?>
            </ol>
            <div class="carousel-inner">
                <?php
                $carouselIndex = 0;
                // Loop para criar os slides do carrossel
                mysqli_data_seek($result, 0); // Voltando ao início do resultado
                while ($row = $result->fetch_assoc()) {
                    $id_link = $row['video_id'];
                    $capa = $row['capa'];
                    $titulo = $row['title'];
                    $posts = $row['posts'];

                    $activeClass = ($carouselIndex == 0) ? 'active' : '';
                    echo "<div class='carousel-item $activeClass'>";
                    echo "<img src='$posts'id='imgCar' class='d-block w-100' alt='$titulo'>";
                    echo "<a class='title-banner' href='index.php?acao=video&video_id=$id_link'><p style='margin: 0; text-overflow: ellipsis; white-space: nowrap; overflow: hidden;'>$titulo</p></a>";
                    echo "</div>";
                    $carouselIndex++;
                }
                ?>
            </div>
            <!-- Controles de navegação do carrossel -->
            <a class="carousel-control-prev" href="#movieCarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Anterior</span>
            </a>
            <a class="carousel-control-next" href="#movieCarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Próximo</span>
            </a>
        </div>
        <?php
        // Conexão com o banco de dados
        include_once 'conect/conexao.php';

        // Consulta para obter os primeiros seis registros de filmes
        $sql_lancamentos = "SELECT `video_id`, `title`, `capa` FROM `tb_video` ORDER BY `data_publicacao` DESC LIMIT 12";
        $result_lancamentos = mysqli_query($conn, $sql_lancamentos);

        $lancamentos = [];
        if ($result_lancamentos) {
            while ($row_lancamento = mysqli_fetch_assoc($result_lancamentos)) {
                $lancamentos[] = $row_lancamento;
            }
        }
        ?>
        <section class="movie-highlights">
            <p style="margin-top:20px !important;">
                Lançamentos
            </p>
            <div class="row">
                <?php foreach ($lancamentos as $lancamento) { ?>
                    <div class="col-4 col-md-2" style="padding:5px;">
                        <a href="index.php?acao=video&video_id=<?php echo $lancamento['video_id']; ?>" class="movie-card">
                            <div style="background-image: url('<?php echo $lancamento['capa']; ?>');" class="movie-image">
                            </div>
                            <img src="assets/64e4213950bad.jpeg" alt="">
                            <p>
                                <?php echo $lancamento['title']; ?>
                            </p>
                        </a>
                    </div>
                <?php } ?>
            </div>
        </section>

        <?php
        $sql_genero = "SELECT * FROM tb_video ORDER BY video_id DESC";
        $result_genero = $conn->query($sql_genero);
        $specifiedGenres = array("ação", "Animação", "Comédia");

        // Define o limite de vídeos por categoria
        $videosPorCategoria = 6;

        foreach ($specifiedGenres as $genre) {
            echo "<section class='movie-highlights'>";
            echo "<p>$genre <a href='index.php?acao=genero&genre=" . $genre . "' class='genre-link'><i class='fas fa-chevron-right'></i> Ver Mais</a></p>";
            echo "<div class='row'>";

            // Loop através de todos os vídeos
            mysqli_data_seek($result_genero, 0); // Voltando ao início do resultado
            $videosExibidos = 0; // Inicializa a contagem de vídeos exibidos
        
            while ($movieRow = $result_genero->fetch_assoc()) {
                $titulo = $movieRow['title'];
                $video_id = $movieRow['video_id'];
                $capa = $movieRow['capa'];
                $generos = array_map('trim', explode(',', $movieRow['genero'])); // Remover espaços em branco
        
                // Verificar se pelo menos um dos gêneros do vídeo está entre os gêneros especificados
                $genreMatch = false;
                foreach ($generos as $videoGenre) {
                    if (strcasecmp($videoGenre, $genre) === 0) {
                        $genreMatch = true;
                        break;
                    }
                }

                if ($genreMatch) {
                    // Verificar se o limite de vídeos por categoria não foi atingido
                    if ($videosExibidos < $videosPorCategoria) {
                        echo '<div class="col-4 col-md-2" style="padding:5px;">';
                        echo '<a href="index.php?acao=video&video_id=' . $video_id . '" class="movie-card">';
                        echo '<div style="background-image: url(' . $capa . ');" class="movie-image"></div>';
                        echo '<img src="assets/64e4213950bad.jpeg" alt="">';
                        echo '<p>' . $titulo . '</p>';
                        echo '</a>';
                        echo '</div>';
                        $videosExibidos++; // Incrementa a contagem de vídeos exibidos
                    } else {
                        // Se o limite foi atingido, saia do loop
                        break;
                    }
                }
            }

            echo "</div>";
            echo "</section>";
        }
        ?>
    </div>
</main>
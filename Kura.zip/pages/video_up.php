<div class="large-max">
<div class="container-max">
<link rel="stylesheet" href="estilo/css/video.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
    .gradiente-bg {
        background: linear-gradient(to bottom, #ff9900, #ff6600);
    }

    .mensagem-conteudo {
        color: #fff;
    }
</style>

<?php include('conect/conexao.php'); ?>
<?php
date_default_timezone_set('America/Fortaleza'); // fuso horário correto
$notifyUser = '';
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Suponha que você tenha o ID do vídeo obtido de alguma forma
    $video_id = $_GET['video_id']; // forma que obtém o ID do vídeo
    $notifyUser = '';

    // Verificar se o usuário já assistiu a este vídeo
    $sql_check = "SELECT * FROM `tb_visualizacoes` WHERE `user_id` = $user_id AND `video_id` = $video_id";
    $result_check = mysqli_query($conn, $sql_check);

    if (mysqli_num_rows($result_check) > 0) {
        // Se o usuário já assistiu, atualize o registro
        $sql_update = "UPDATE `tb_visualizacoes` SET `data_visualizacao` = NOW() WHERE `user_id` = $user_id AND `video_id` = $video_id";
        mysqli_query($conn, $sql_update);
    } else {
        // Se é a primeira vez, crie um novo registro
        $sql_insert = "INSERT INTO `tb_visualizacoes` (`user_id`, `video_id`, `data_visualizacao`) VALUES ($user_id, $video_id, NOW())";
        mysqli_query($conn, $sql_insert);
    }
} else {
    // Se o usuário não estiver logado, exiba uma notificação flutuante
    $notifyUser = '<div class="alert alert-warning alert-dismissible fade show mt-3 gradiente-bg" role="alert">
    <strong class="mensagem-conteudo"> <!-- Aplicando o estilo ao conteúdo da mensagem -->
                Você não está logado. Por favor, <a href="login.php" class="alert-link">faça o login</a> para melhorar sua experiência.
            </strong>
    <button type="button" class="close" data-dismiss="alert" aria-label="Fechar">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>';
}
?>

<?php
$video_data = null;

// Verifica se o parâmetro video_id está presente na URL
if (isset($_GET['video_id'])) {
    $video_id = $_GET['video_id'];

    // Faz um SELECT na tabela tb_video para obter os dados do vídeo com o ID correspondente
    $sql = "SELECT `video_id`, `title`, `url`, `descricao`, `data_publicacao`, `classificacao`, `genero` FROM `tb_video` WHERE `video_id` = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $video_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Verifica se o vídeo foi encontrado
    if ($result->num_rows > 0) {
        $video_data = $result->fetch_assoc();
    } else {
        // Caso o vídeo não seja encontrado, exiba uma mensagem ou redirecione para uma página de erro
        echo "Vídeo não encontrado.";
        header('Location: 3, index.php?acao=erro');
        exit;
    }
} else {
    // Caso o parâmetro video_id não esteja presente na URL, exiba uma mensagem ou redirecione para uma página de erro
    echo "ID de vídeo não fornecido.";
    header('Location: 3, index.php?acao=erro');
    exit;
}
?>
<?php
if (isset($_GET['video_id'])) {
    $video_id_visu = $_GET['video_id'];
    // Consultar o banco de dados para obter a contagem de visualizações
    $query = "SELECT COUNT(*) as total_visualizacoes FROM tb_visualizacoes WHERE video_id = $video_id_visu";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $total_visualizacoes = $row['total_visualizacoes'];
}
?>

<!-- ... (restante do código) -->
<div class="container">
    <?php
    echo $notifyUser;

    // Consulta para recuperar o título e a URL do vídeo
    $video_id = $video_data['video_id']; // O ID do vídeo desejado
    $selectV = "SELECT * FROM tb_video WHERE video_id = $video_id";
    $video_result = $conn->query($selectV);

    // Inicialize as variáveis para armazenar os valores
    $video_title = "Título do Vídeo";
    $video_url = "uploads/";

    if ($video_result->num_rows > 0) {
        $video_row = $video_result->fetch_assoc();
        $video_title = $video_row["title"];
        $video_url = $video_row["url"];
        $descricao = $video_row["descricao"];
        $classificacao = $video_row["classificacao"];
        $genero = $video_row["genero"];
    }
    ?>
    <div class="film-title text-center mb-3 descricao" style="color:#fff; font-weight: 900; text-transform: uppercase;">
        <?php echo $video_title; ?>
    </div>
    <div id="video-container">
        <?php if (isVideoLink($video_url)): ?>
            <video id="video">
                <source src="<?php echo $video_url; ?>" type="video/mp4">
                Seu navegador não suporta o elemento de vídeo.
            </video>

            <div class="custom-controls-2">
                <button class="custom-button" id="play-pause-button"><i class="fas fa-play"></i></button>
                <div class="volume-touch-area up"></div>
                <div class="volume-touch-area down"></div>
            </div>
            <div class="custom-controls">
                <span id="timer">0:00 / 0:00</span>
                <button class="custom-button" id="skip-back-button"><i class="fas fa-backward"></i></button>
                <button class="custom-button" id="restart-button"><i class="fas fa-redo-alt"></i></button>
                <button class="custom-button" id="skip-forward-button"><i class="fas fa-forward"></i></button>
                <button class="custom-button" id="mute-button"><i class="fas fa-volume-up"></i></button>
                <span id="volume-value">100%</span>
                <button id="fullscreen-button">
                    <i class="fas fa-expand" style="margin-right:10px;"></i>
                    full
                </button>

                <div class="progress-bar-container">
                    <progress id="progress" value="0" max="100"></progress>
                </div>
            </div>
        <?php elseif (isIframeLink($video_url)): ?>
            <iframe src="<?php echo $video_url; ?>" allowfullscreen></iframe>
        <?php else: ?>
            <p>Formato de vídeo não suportado.</p>
        <?php endif; ?>
    </div>

    <?php
    function isVideoLink($url)
    {
        $video_extensions = array("mp4", "avi", "mov"); // Adicione mais extensões se necessário
        $url_extension = pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION);
        return in_array($url_extension, $video_extensions);
    }

    function isIframeLink($url)
    {
        // Verifica se o URL corresponde ao padrão do Google Drive para links de vídeo
        if (preg_match('/https:\/\/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)\/preview/', $url, $matches)) {
            return true;
        }
        // Verifica se o conteúdo do atributo src corresponde ao padrão do OneDrive para links de vídeo em iframes
        if (preg_match('/https:\/\/onedrive\.live\.com\/embed\?resid=[a-zA-Z0-9%]+&authkey=[!a-zA-Z0-9]+/', $url, $matches)) {
            return true;
        }
        // Verifica se o URL corresponde ao padrão do OK.ru para links de vídeo em iframes
        if (preg_match('/\ok\.ru\/videoembed\/[0-9]+/', $url, $matches)) {
            return true;
        }
        // Adiciona verificação para o padrão do Mixdrop
        if (preg_match('/https:\/\/mixdrop21\.net\/e\/[a-zA-Z0-9]+/', $url)) {
            return true;
        }
        // Adiciona verificação para o padrão do rede canais
        if (preg_match('/https:\/\/sinalpublico\.co\/player3\/serverf3hlb\.php\?vid\=[a-zA-Z0-9]/', $url)) {
            return true;
        }
        // Adiciona verificação para o padrão do rede canais
        if (preg_match('/https:\/\/sinalpublico\.cc\/player3\/serverf3hlb\.php\?vid\=[a-zA-Z0-9]/', $url)) {
            return true;
        }
        return false;
    }

    ?>

</div>
<div class="container" style="margin-top:10px;">
    <div class="descricao"
        style="color:#fff; font-weight: 900; text-transform: uppercase; display: flex; align-items: center; justify-content: flex-start; flex-direction: row; padding: 5px 10px 5px 10px !important;">
        <!--<span><i style="color: #ff0000;" class="fas fa-eye view-icon"></i>
            <?php echo $total_visualizacoes; ?>
        </span>-->
        <span> Gênero:
            <?php echo $genero; ?>
        </span>
    </div>
    <p class="descricao">
        <?php
        // Verifica se a descrição existe
        if (isset($descricao) && !empty($descricao)) {
            echo '<strong style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 5px;">SINOPSE: <span style="color:#ff0000; font-weight: 900; text-transform: uppercase;">Classificação indicativa (' . $classificacao . ')</span></strong>' . $descricao; // Exibe a descrição
        } else {
            echo "<strong>Descrição Indefinida</strong>"; // Exibe mensagem de descrição indefinida
        }
        ?>
    </p>
</div>
<script src="estilo/script/script.js"></script>
<div class="container comments-section">
    <h2 class="mb-3">Comentários</h2>
    <div class="ara-comentarios">
        <?php
        // Consulta para recuperar os comentários
        $sql = "SELECT tb_user.username, tb_coment.comment_text, tb_coment.timestamp
    FROM tb_coment
    INNER JOIN tb_user ON tb_coment.user_id = tb_user.user_id WHERE video_id = '$video_id'
    ORDER BY tb_coment.timestamp DESC";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Loop para exibir os comentários
            while ($row = $result->fetch_assoc()) {
                echo '<div class="comment">
            <div class="comment-author fw-bold">' . $row["username"] . '</div>
            <div class="comment-date text-muted">' . date('d/m/Y H:i:s', strtotime($row['timestamp'])) . '</div>
            <div class="comment-text mt-2">' . $row["comment_text"] . '</div>
        </div>';
            }
        } else {
            echo "Ainda não há comentários.";
        }
        ?>
    </div>
    <!-- Repita a estrutura acima para mais exemplos de comentários -->

    <div class="comment-form mt-4">
        <h3>Deixe um Comentário</h3>
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        <?php if (isset($_SESSION['user_id'])): ?>
            <!-- Formulário de comentário -->
            <form method="post">
                <textarea class="form-control mb-2" rows="4" name="comment_text"
                    placeholder="Escreva seu comentário"></textarea>
                <button class="btn btn-primary" type="submit"><i class="fas fa-paper-plane"></i> Enviar</button>
            </form>
        <?php else: ?>
            <!-- Mensagem para usuários não logados -->
            <p>Você precisa estar logado para deixar um comentário. <a style="color: #ff0000; font-weight:700;"
                    href="login.php">Login</a></p>
        <?php endif; ?>
    </div>
    <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_SESSION['user_id'])) {
            $comment_text = $_POST["comment_text"];
            if (!empty($comment_text)) {
                $user_id = $_SESSION['user_id'];
                $video_id = $video_data['video_id'];

                $sql = "INSERT INTO tb_coment (user_id, video_id, comment_text) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("iis", $user_id, $video_id, $comment_text);

                if ($stmt->execute()) {
                    // Redirecionar após inserir o comentário
                    echo '<meta http-equiv="refresh" content="4">';
                    exit;
                } else {
                    $error_message = 'Erro ao inserir comentário';
                }
            }
        } else {
            // Usuário não logado, redirecionar ou exibir mensagem de erro
            // Por exemplo:
            header('Location: login.php'); // Redirecionar para a página de login
            exit;
        }
    }

    ?>

</div>
</div>
<div class="container-min">
    <div class="film-title text-center mb-3 descricao" style="color:#fff; font-weight: 900; text-transform: uppercase;">
        ADS
    </div>
</div>
</div>
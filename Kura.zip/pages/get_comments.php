<?php
include('../conect/conexao.php');
session_start();

$video_id =  $_GET['video_id'];

// Consulta para recuperar os comentários do banco de dados
$sql = "SELECT tb_user.username, tb_coment.comment_text, tb_coment.timestamp
        FROM tb_coment
        INNER JOIN tb_user ON tb_coment.user_id = tb_user.user_id
        WHERE video_id = ?
        ORDER BY tb_coment.timestamp DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $video_id); // Assume que o ID do vídeo é enviado via POST
$stmt->execute();
$result = $stmt->get_result();

$commentsHtml = ''; // Variável para armazenar o HTML dos comentários

if ($result->num_rows > 0) {
    // Loop para criar o HTML dos comentários
    while ($row = $result->fetch_assoc()) {
        $commentsHtml .= '<div class="comment">
            <div class="comment-author fw-bold">' . $row["username"] . '</div>
            <div class="comment-date text-muted">' . date('d/m/Y H:i:s', strtotime($row['timestamp'])) . '</div>
            <div class="comment-text mt-2">' . nl2br($row["comment_text"]) . '</div>
        </div>';
    }
} else {
    $commentsHtml = '<div class="no-comments">Ainda não há comentários.</div>';
}

// Retorna os comentários em formato JSON
echo json_encode(['commentsHtml' => $commentsHtml]);
?>
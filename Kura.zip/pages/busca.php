<style>
    .row {
        width: 100%;
        padding: 5px 0 5px 0;
        margin: 0 !important;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        padding-bottom: 0 !important;
    }

    .movie-card {
        margin-bottom: 0 !important;
    }
</style>
<?php
// Conexão com o banco de dados (substitua os valores pelos seus próprios)
include_once('conect/conexao.php');

// Verifica se o formulário de pesquisa foi enviado
if (isset($_POST['search'])) {
    $search_term = $_POST['search'];

    // Faz a conexão com o banco de dados
    include('conect/conexao.php');

    // Consulta SQL para buscar filmes com base no termo de pesquisa
    $sql = "SELECT * FROM tb_video WHERE title LIKE '%$search_term%'";
    $result = $conn->query($sql);

    // Exibe os resultados da pesquisa
    if ($result->num_rows > 0) {
        echo "<section class='movie-highlights'>";
        echo '<h4><strong>RESULTADO DA PESQUISA:</strong></h4>';
        echo "<div class='row'>";
        // Exiba os resultados da pesquisa
        while ($row = $result->fetch_assoc()) {
            echo '<div class="col-md-4" style="margin: 15px 0 15px 0">';
            echo '<a href="index.php?acao=video&video_id=' . $row['video_id'] . '" class="movie-card">';
            echo '<div style="background-image: url(' . $row['capa'] . ');" class="movie-image"></div>';
            echo '<img src="assets/64e4213950bad.jpeg" alt="">';
            echo '<p>' . $row['title'] . '</p>';
            echo '</a>';
            echo '</div>';
            // Adicione mais campos conforme necessário
            echo "<hr>";
        }
        echo "</div>";
        echo "</section>";
    } else {
        echo "<section class='movie-highlights'>";
        echo "<h4><strong>Nenhum resultado encontrado.</strong></h4>";
        echo "</section>";
    }

    // Feche a conexão com o banco de dados
    $conn->close();
} else {
    // ... Lógica para outras ações, como exibir a página inicial ...
}
?>
<style>
    .error-container {
        text-align: center;
        padding: 20px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
    }

    .error-code {
        font-size: 72px;
        color: #f44336;
        margin-bottom: 10px;
    }

    .error-message {
        font-size: 24px;
        color: #fff;
        /* Cor do texto clara */
        margin-bottom: 20px;
    }

    .back-button {
        text-decoration: none;
        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        border-radius: 5px;
        font-size: 18px;
    }

    .back-button:hover {
        background-color: #45a049;
    }
</style>

<main>
    <div class="error-container">
        <div class="error-code">404</div>
        <div class="error-message">Oops ! A página que você está procurando não foi encontrada.</div><a
            class="back-button" href="index.php">Voltar para a Página Inicial</a>
    </div>
</main>
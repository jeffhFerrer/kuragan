<?php
// Faz a conexão com o banco de dados
include('conect/conexao.php');

// Faz um SELECT na tabela tb_video para obter os dados dos vídeos que contenham o gênero selecionado
$sql = "SELECT * FROM tb_video ORDER BY video_id DESC";
$result = $conn->query($sql);
?>

<style>
    .row {
        width: 100%;
        padding: 5px 0 5px 0;
        margin: 0 !important;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        padding-bottom: 0 !important;
    }

    .movie-card {
        margin-bottom: 0 !important;
    }
</style>
<?php if (isset($_GET['genre'])) {
    // Verifica qual gênero foi selecionado na URL
    $selectedGenre = $_GET['genre'];
    ?>
    <main>
        <div class="container">
            <?php
            $specifiedGenres = array('' . $selectedGenre . '');

            foreach ($specifiedGenres as $genre) {
                echo "<section class='movie-highlights'>";
                echo "<p style='width: 100%; text-align:center; text-transform:uppercase; font-size:20px;'>$genre</p>";
                echo "<div class='row'>";

                // Variável para verificar se pelo menos um vídeo foi exibido
                $videoDisplayed = false;

                // Loop através de todos os vídeos
                mysqli_data_seek($result, 0); // Voltando ao início do resultado
                while ($movieRow = $result->fetch_assoc()) {
                    $titulo = $movieRow['title'];
                    $video_id = $movieRow['video_id'];
                    $capa = $movieRow['capa'];
                    $generos = array_map('trim', explode(',', $movieRow['genero'])); // Remover espaços em branco
        
                    // Verificar se o gênero do loop externo está entre os gêneros do vídeo
                    if (in_array(strtolower($genre), array_map('strtolower', $generos))) {
                        echo '<div class="col-md-4" style="margin: 15px 0 15px 0">';
                        echo '<a href="index.php?acao=video&video_id=' . $video_id . '" class="movie-card">';
                        echo '<div style="background-image: url(' . $capa . ');" class="movie-image"></div>';
                        echo '<img src="assets/64e4213950bad.jpeg" alt="">';
                        echo '<p>' . $titulo . '</p>';
                        echo '</a>';
                        echo '</div>';

                        // Definir a variável para true pois um vídeo foi exibido
                        $videoDisplayed = true;
                    }
                }

                // Verificar se pelo menos um vídeo foi exibido
                if (!$videoDisplayed) {
                    echo '<p style="width: 100%; text-align:center; color:#ff0000;">Nenhum vídeo encontrado com o gênero ' . $genre . '</p>';
                }

                echo "</div>";
                echo "</section>";
            }

            ?>
        </div>
    </main>
<?php } elseif (isset($_GET['allview'])) { ?>
    <main>
        <div class="container">
            <?php
            $allview = $_GET['allview'];
            echo "<section class='movie-highlights'>";
            echo "<p style='width: 100%; text-align:center; text-transform:uppercase; font-size:20px;'>$allview</p>";
            echo "<div class='row'>";

            // Variável para verificar se pelo menos um vídeo foi exibido
            $videoDisplayed = false;

            // Loop através de todos os vídeos
            mysqli_data_seek($result, 0); // Voltando ao início do resultado
            while ($movieRow = $result->fetch_assoc()) {
                $titulo = $movieRow['title'];
                $video_id = $movieRow['video_id'];
                $capa = $movieRow['capa'];

                echo '<div class="col-4 col-md-2" style="padding:5px;">';
                echo '<a href="index.php?acao=video&video_id=' . $video_id . '" class="movie-card">';
                echo '<div style="background-image: url(' . $capa . ');" class="movie-image"></div>';
                echo '<img src="assets/64e4213950bad.jpeg" alt="">';
                echo '<p>' . $titulo . '</p>';
                echo '</a>';
                echo '</div>';

                // Definir a variável para true pois um vídeo foi exibido
                $videoDisplayed = true;
            }

            // Verificar se pelo menos um vídeo foi exibido
            if (!$videoDisplayed) {
                echo '<p style="width: 100%; text-align:center; color:#ff0000;">Nenhum vídeo encontrado com o gênero ' . $genre . '</p>';
            }

            echo "</div>";
            echo "</section>";

            ?>
        </div>
    </main>
<?php } else { ?>
    <main>
        <div class="container">
            <section class='movie-highlights'>
                <p style='width: 100%; text-align:center; text-transform:uppercase; font-size:20px;'>Não Há Nenhuma Informação Relevante na URL</p>
            </section>
        </div>
    </main>
    <?php
} ?>
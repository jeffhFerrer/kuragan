<link rel="stylesheet" href="estilo/css/forms.css">
<main class="container-form">
    <form action="" method="post" enctype="multipart/form-data" id="form-cont">
        <div class="form-group">
            <input type="text" class="form-control" id="nome" name="nome" required placeholder="Digite seu nome...">
        </div>

        <div class="form-group">
            <input type="email" class="form-control" id="email" name="email" required
                placeholder="Digite seu e-mail...">
        </div>

        <div class="form-group">
            <label for="foto" class="label">Selecione um arquivo de imagem</label>
            <input type="file" class="form-control-file" id="foto" name="foto" accept="image/*" required hidden>
        </div>

        <div class="form-group">
            <input type="password" class="form-control" id="senha" name="senha" required minlength="6" maxlength="20"
                placeholder="Digite uma senha...">
        </div>

        <div class="form-group">
            <input type="password" class="form-control" id="confirmaSenha" name="confirmaSenha" required minlength="6"
                maxlength="20" placeholder="Confirme sua senha...">
        </div>

        <div class="form-group">
            <input type="text" class="form-control" id="dataNascimento" name="dataNascimento" required
                placeholder="Sua data de nascimento...">
        </div>

        <div class="form-group">
            <button type="submit" class="btn">Cadastrar</button>
            <a href="login.php">ir para o login</a>
        </div>
    </form>
    <?php
    include_once('conect/conexao.php');

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nome = cleanInput($_POST["nome"]);
        $email = cleanInput($_POST["email"]);
        $foto = $_FILES["foto"]["name"];
        $senha = password_hash($_POST["senha"], PASSWORD_DEFAULT);
        $dataNascimento = $_POST["dataNascimento"];

        // Verificar se a senha é igual à confirmação de senha
        if ($_POST["senha"] !== $_POST["confirmaSenha"]) {
            echo "A senha e a confirmação de senha não coincidem.";
        } else {
            // Gerar uma chave única com 10 caracteres alfanuméricos
            $chaveUnica = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 10);

            // Verificar a unicidade da chave única
            $chaveExiste = true;

            while ($chaveExiste) {
                // Verificar se a chave já existe no banco de dados
                $sqlVerificarChave = "SELECT user_id FROM tb_user WHERE chave_unica = '$chaveUnica'";
                $result = $conn->query($sqlVerificarChave);

                if ($result->num_rows == 0) {
                    // A chave não existe, pode ser usada
                    $chaveExiste = false;
                } else {
                    // A chave já existe, gere uma nova chave única
                    $chaveUnica = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 10);
                }
            }

            $nomeFoto = uniqid() . "_" . $_FILES["foto"]["name"];
            $uploadPath = "assets/user/" . $nomeFoto;
            move_uploaded_file($_FILES["foto"]["tmp_name"], $uploadPath);

            // Inserir os dados no banco de dados, incluindo a chave única
            $sql = "INSERT INTO tb_user (tipo_user, username, email, foto, senha, data_nascimento, chave_unica)
            VALUES ('1','$nome', '$email', '$nomeFoto', '$senha', '$dataNascimento', '$chaveUnica')";

            if ($conn->query($sql) === TRUE) {
                // Após inserir o usuário com sucesso, obter o ID do usuário recém-inserido
                $userID = $conn->insert_id;

                // Mensagem de boas-vindas
                $mensagemBoasVindas = "Bem-vindo ao nosso site!</br>Esperamos que sua experiência em nossa plataforma seja a melhor possível";

                // Inserir a mensagem de boas-vindas na tabela tb_notificacoes
                $sqlNotificacao = "INSERT INTO tb_notificacoes (user_id, mensagem, data, lida) VALUES ('$userID', '$mensagemBoasVindas', NOW(), 0)";

                if ($conn->query($sqlNotificacao) === TRUE) {
                    echo '<div id="ok-sucess"> Usuário cadastrado com sucesso, não esqueça de checar as notificações!</div>';
                } else {
                    echo '<div id="no-sucess">ERRO ao cadastrar usuário.</div>';
                }
            } else {
                echo '<div id="no-sucess">ERRO ao cadastrar usuário.</div>';
            }
        }
    }

    // Função para limpar os dados de entrada
    function cleanInput($input)
    {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input);
        return $input;
    }
    ?>

</main>
<script>
    const dataNascimentoInput = document.getElementById('dataNascimento');

    dataNascimentoInput.addEventListener('input', function () {
        const value = this.value.replace(/\D/g, '');
        if (value.length > 0) {
            if (value.length > 2) {
                this.value = `${value.slice(0, 2)}/${value.slice(2, 4)}/${value.slice(4, 8)}`;
            } else if (value.length > 4) {
                this.value = `${value.slice(0, 2)}/${value.slice(2, 4)}/${value.slice(4, 8)}`;
            }
        }
    });

</script>
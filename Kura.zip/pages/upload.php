<main class="container my-4">
    <h2 class="mb-4">Upload e Informações de Filmes</h2>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <input type="radio" name="uploadOption" value="upload" id="uploadOption" checked>
            <label for="uploadOption">Upload de Vídeo</label><br>

            <input type="radio" name="uploadOption" value="url" id="urlOption">
            <label for="urlOption">Link URL do Vídeo</label><br>
        </div>

        <div id="uploadSection">
            <div class="form-group">
                <label for="videoFile">Vídeo:</label>
                <div class="custom-file">
                    <input class="custom-file-input" type="file" name="videoFile" id="videoFile" accept="video/*">
                    <label class="custom-file-label" for="videoFile">Escolha um arquivo de imagem</label>
                </div>
            </div>
        </div>

        <div id="urlSection" style="display: none;">
            <div class="form-group">
                <label for="videoURL">URL</label>
                <input class="form-control" type="text" name="videoURL" id="videoURL" placeholder="URL do Vídeo">
            </div>
        </div>
        <script>
            const uploadOption = document.getElementById('uploadOption');
            const urlOption = document.getElementById('urlOption');
            const uploadSection = document.getElementById('uploadSection');
            const urlSection = document.getElementById('urlSection');

            uploadOption.addEventListener('change', () => {
                uploadSection.style.display = 'block';
                urlSection.style.display = 'none';
            });

            urlOption.addEventListener('change', () => {
                uploadSection.style.display = 'none';
                urlSection.style.display = 'block';
            });
        </script>
        <div class="form-group">
            <label for="capa">Capa do Vídeo:</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="capa" name="capa" accept="image/*" required>
                <label class="custom-file-label" for="capa">Escolha um arquivo de imagem</label>
            </div>
        </div>

        <div class="form-group">
            <label for="posts">Post de Apresentação (1110x500):</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="posts" name="posts" accept="image/*" required>
                <label class="custom-file-label" for="posts">Escolha um arquivo de imagem</label>
            </div>
        </div>

        <div class="form-group">
            <label for="classificacao">Classificação Indicativa:</label>
            <select class="form-control" id="classificacao" name="classificacao" required>
                <option value="">Selecione a classificação indicativa</option>
                <option value="Livre">Livre</option>
                <option value="10+">10+</option>
                <option value="12+">12+</option>
                <option value="14+">14+</option>
                <option value="16+">16+</option>
                <option value="18+">18+</option>
            </select>
        </div>


        <div class="form-group">
            <label for="titulo">Título:</label>
            <input type="text" class="form-control" name="titulo" required>
        </div>

        <div class="form-group">
            <label for="descricao">Descrição:</label>
            <textarea class="form-control" name="descricao" rows="4" required></textarea>
        </div>

        <div class="form-group">
            <label for="genero">Gênero:</label>
            <input type="text" class="form-control" name="genero" required>
        </div>

        <button type="submit" class="btn btn-primary" name="submit">Enviar Vídeo</button>
    </form>
    <?php
    include_once('conect/conexao.php');

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
        $titulo = cleanInput($_POST["titulo"]);
        $descricao = cleanInput($_POST["descricao"]);
        $genero = cleanInput($_POST["genero"]);
        $classificacao = cleanInput($_POST["classificacao"]);

        // ... (outras validações e preparação de dados)
    
        $capaName = generateUniqueFileName($_FILES["capa"]["name"]);
        $capaTmp = $_FILES["capa"]["tmp_name"];

        $capaExtension = strtolower(pathinfo($capaName, PATHINFO_EXTENSION));
        $allowedImageExtensions = array("jpg", "jpeg", "png", "gif");

        if (in_array($capaExtension, $allowedImageExtensions)) {
            $uploadCapaPath = "assets/video/capa/" . $capaName;
            if (move_uploaded_file($capaTmp, $uploadCapaPath)) {
                // Upload de imagem extra (posts)
                $postsName = generateUniqueFileName($_FILES["posts"]["name"]);
                $postsTmp = $_FILES["posts"]["tmp_name"];

                $postsExtension = strtolower(pathinfo($postsName, PATHINFO_EXTENSION));

                if (in_array($postsExtension, $allowedImageExtensions)) {
                    $uploadPostsPath = "assets/video/posts/" . $postsName;
                    if (move_uploaded_file($postsTmp, $uploadPostsPath)) {
                        if ($_POST["uploadOption"] === "upload") {
                            if (isset($_FILES["videoFile"])) {
                                $videoName = generateUniqueFileName($_FILES["videoFile"]["name"]);
                                $videoTmp = $_FILES["videoFile"]["tmp_name"];

                                $videoExtension = strtolower(pathinfo($videoName, PATHINFO_EXTENSION));
                                $allowedVideoExtensions = array("mp4", "avi", "mov");

                                if (in_array($videoExtension, $allowedVideoExtensions)) {
                                    $uploadVideoPath = "uploads/" . $videoName;
                                    if (move_uploaded_file($videoTmp, $uploadVideoPath)) {
                                        // Salvar os dados no banco de dados
                                        $dataHoraAtual = date("Y-m-d H:i:s");
                                        $sql = "INSERT INTO tb_video (title, url, descricao, data_publicacao, classificacao, genero, capa, posts)
                                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

                                        $stmt = $conn->prepare($sql);
                                        if (!$stmt) {
                                            die('Erro na preparação da consulta: ' . $conn->error);
                                        }

                                        $stmt->bind_param("ssssssss", $titulo, $uploadVideoPath, $descricao, $dataHoraAtual, $classificacao, $genero, $uploadCapaPath, $uploadPostsPath);

                                        if ($stmt->execute()) {
                                            echo "Vídeo, imagem da capa, imagem extra e informações enviados com sucesso!";
                                        } else {
                                            echo "Erro ao enviar o vídeo, imagem da capa, imagem extra e informações.";
                                        }

                                        $stmt->close();
                                    } else {
                                        echo "Erro ao carregar o vídeo.";
                                    }
                                } else {
                                    echo "Formato de vídeo não suportado. Apenas formatos MP4, AVI e MOV são permitidos.";
                                }
                            }
                        } elseif ($_POST["uploadOption"] === "url") {
                            if (isset($_POST["videoURL"])) {
                                $videoURL = $_POST["videoURL"];
                                // Salvar os dados no banco de dados
                                $dataHoraAtual = date("Y-m-d H:i:s");
                                $sql = "INSERT INTO tb_video (title, url, descricao, data_publicacao, classificacao, genero, capa, posts)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

                                $stmt = $conn->prepare($sql);
                                if (!$stmt) {
                                    die('Erro na preparação da consulta: ' . $conn->error);
                                }

                                $stmt->bind_param("ssssssss", $titulo, $videoURL, $descricao, $dataHoraAtual, $classificacao, $genero, $uploadCapaPath, $uploadPostsPath);

                                if ($stmt->execute()) {
                                    echo "Vídeo, imagem da capa, imagem extra e informações enviados com sucesso!";
                                } else {
                                    echo "Erro ao enviar o vídeo, imagem da capa, imagem extra e informações.";
                                }
                            }
                        }
                    } else {
                        echo "Erro ao carregar a imagem extra.";
                    }
                } else {
                    echo "Formato de imagem não suportado. Apenas formatos JPG, JPEG, PNG e GIF são permitidos.";
                }
            } else {
                echo "Erro ao carregar a imagem da capa.";
            }
        } else {
            echo "Formato de imagem não suportado. Apenas formatos JPG, JPEG, PNG e GIF são permitidos.";
        }
    }

    // Fechamento da conexão com o banco de dados
    $conn->close();

    function cleanInput($input)
    {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input);
        return $input;
    }

    function generateUniqueFileName($originalName)
    {
        $extension = pathinfo($originalName, PATHINFO_EXTENSION);
        $newName = uniqid() . '.' . $extension;
        return $newName;
    }
    ?>

</main>
<style>
        /* Estilos para a imagem */
        .logo-img {
            max-width: 200px;
            height: 200px;
            border: 3px solid #fff;
            border-radius: 100%;
            float: left; /* Alinha a imagem à esquerda */
            margin-right: 20px; /* Espaçamento entre a imagem e o texto */
            margin-bottom: 20px; /* Espaçamento abaixo da imagem */
        }

        /* Estilos para o texto */
        p {
            text-align: justify;
        }
    </style>
<div class="container" style="padding: 0 20px; margin-top: 0;">
        <div class="row">
            <div class="col-md-12 text-center" style="margin-top: 0;">
                <h3 class="mt-5 mb-4" style="margin-top: 0;">Sobre Kuragan</h3>
                <p>
                    <img src="icon.png" alt="Logo Kuragan" class="img-fluid mb-4 logo-img">
                    Bem-vindo à Kuragan, onde a diversão encontra a comunidade! Somos uma plataforma de streaming que oferece uma ampla variedade de filmes de diversos gêneros para todos os gostos. Aqui, você pode mergulhar em dramas emocionantes, aventuras empolgantes, comédias hilárias e muito mais, tudo isso ao alcance de um clique.
                </p>
                <p>
                    Mas a Kuragan vai além de apenas entretenimento; somos uma comunidade vibrante e acolhedora. Nossa plataforma inclui salas de chat públicas e privadas, permitindo que você se conecte com pessoas de todo o mundo que compartilham seus interesses cinematográficos.
                </p>
                <p>
                    Nosso compromisso com a liberdade de expressão é fundamental. Os usuários podem se expressar livremente nos chats públicos e privados, bem como nos comentários dos vídeos, criando uma experiência de interação rica e envolvente.
                </p>
                <p>
                    Valorizamos cada membro de nossa comunidade e buscamos garantir sua satisfação em todos os aspectos. Nossa equipe de suporte está disponível 24 horas por dia, garantindo um retorno rápido para todas as suas consultas e necessidades.
                </p>
                <p>
                    Além disso, oferecemos aos nossos usuários a oportunidade única de participar ativamente da comunidade como administradores da plataforma. Seja através de convites especiais ou candidaturas, convidamos os membros mais engajados a se tornarem parte essencial da nossa equipe administrativa.
                </p>
                <p>
                    Na Kuragan, não somos apenas uma plataforma de filmes; somos uma grande família unida pelo amor ao cinema, pela interação social e pelo compartilhamento de experiências. Junte-se a nós e faça parte dessa incrível jornada de entretenimento e comunidade!
                </p>
            </div>
        </div>
    </div>
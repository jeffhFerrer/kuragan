<?php
include('conect/conexao.php');

// Definir o valor padrão para a quantidade de registros por página
$registrosPorPagina = isset($_POST['registros_por_pagina']) ? $_POST['registros_por_pagina'] : 10;

// Consulta para obter os registros de vídeos da tabela tb_video
$sql = "SELECT v.video_id, v.title, v.capa, v.data_publicacao
        FROM tb_video v";

// Filtro de busca
if (isset($_POST['search']) && !empty($_POST['search'])) {
    $search = $_POST['search'];
    $sql .= " WHERE v.title LIKE '%$search%'";
}

$sql .= " ORDER BY v.video_id DESC";

// Adicionar o LIMIT para controlar a quantidade de registros exibidos
if ($registrosPorPagina !== 'all') {
    $sql .= " LIMIT $registrosPorPagina";
}

$result = $conn->query($sql);
?>
<style>
    .container {
        margin-top: 50px;
    }

    h1 {
        text-align: center;
        margin-bottom: 20px;
    }

    .table th {
        background-color: #343a40;
        color: #fff;
        font-weight: bold;
        font-size: 16px;
        border: none;
        text-align: center;
    }

    .table td {
        vertical-align: middle;
        text-align: center;
        color: #fff;
    }

    .user-photo {
        width: 50px;
        height: 50px;
        border-radius: 100%;
        object-fit: cover;
    }

    /* Estilo personalizado para o campo de busca */
    .search-container {
        display: flex;
        align-items: center;
        margin-bottom: 20px;
    }

    .search-input {
        flex: 1;
        padding: 10px;
        color: #fff;
        font-weight: 700;
        border: 1px solid #ccc;
        border-top-left-radius: 5px;
        border-bottom-left-radius: 5px;
        background: transparent;
        outline: none;
    }

    .search-button {
        background-color: #007bff;
        border: none;
        color: #fff;
        padding: 10px 15px;
        border: 1px solid #007bff;
        border-top-right-radius: 5px;
        border-bottom-right-radius: 5px;
        cursor: pointer;
    }

    #registros_por_pagina {
        background: transparent;
        outline: none;
        color: #fff;
        font-weight: 700;
    }

    .table td .dropdown-menu {
        position: absolute;
        float: center;
        display: none;
        min-width: 100%;
        padding: 5px;
        margin: 0;
        font-size: 1rem;
        color: #212529;
        text-align: center;
        list-style: none;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid rgba(0, 0, 0, .15);
        border-radius: .25rem;
    }

    .table td:hover .dropdown-menu {
        display: block;
        margin-top: 10px;
    }

    .table td .dropdown-item {
        display: block;
        width: 100%;
        padding: 10px;
        clear: both;
        font-weight: 400;
        color: #212529;
        text-align: center;
        white-space: nowrap;
        background-color: transparent;
        border: 0;
    }
</style>

<div class="container">
    <h1>Registros de Vídeos</h1>
    <form action="" method="post">
        <div class="search-container">
            <input type="text" class="search-input" id="search" name="search"
                value="<?php echo isset($_POST['search']) ? $_POST['search'] : ''; ?>" placeholder="Buscar por Título">
            <button type="submit" class="search-button"><i class="fas fa-search"></i></button>
        </div>
    </form>
    <div class="form-group">
        <form action="" method="post">
            <label for="registros_por_pagina">Quantidade de Registros por Página:</label>
            <select class="form-control" id="registros_por_pagina" name="registros_por_pagina"
                onchange="this.form.submit()">
                <option value="5" <?php if ($registrosPorPagina == 5)
                    echo 'selected'; ?>>
                    5
                </option>
                <option value="10" <?php if ($registrosPorPagina == 10)
                    echo 'selected'; ?>>
                    10
                </option>
                <option value="25" <?php if ($registrosPorPagina == 25)
                    echo 'selected'; ?>>
                    25
                </option>
                <option value="50" <?php if ($registrosPorPagina == 50)
                    echo 'selected'; ?>>
                    50
                </option>
                <option value="all" <?php if ($registrosPorPagina == 'all')
                    echo 'selected'; ?>>
                    Todos
                </option>
            </select>
            <input type="hidden" name="search" value="<?php echo isset($_POST['search']) ? $_POST['search'] : ''; ?>">
            <input type="hidden" name="acao" value="videos">
        </form>
    </div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Capa</th>
                <th>Título do Vídeo</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $contador = 1; // Inicializar o contador
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $contador . '</td>';
                    echo '<td><img src="' . $row["capa"] . '" alt="Capa do Vídeo" class="user-photo"></td>';
                    echo '<td>' . $row["title"] . '</td>';
                    echo '<td>';
                    echo '<div class="dropdown">';
                    echo '<button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Ações</button>';
                    echo '<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">';
                    echo '<a class="dropdown-item" href="index.php?acao=update-filme&video_id=' . $row["video_id"] . '" onclick="return confirm(\'Tem certeza que deseja editar este vídeo?\');">Editar</a>';
                    echo '<a class="dropdown-item" href="index.php?acao=delete-filme&video_id=' . $row["video_id"] . '" onclick="return confirm(\'Tem certeza que deseja excluir este vídeo?\');">Excluir</a>';
                    echo '</div>';
                    echo '</div>';
                    echo '</td>';
                    echo '</tr>';
                    $contador++;
                }
            } else {
                echo '<tr><td colspan="4">Nenhum registro de vídeo encontrado.</td></tr>';
            }
            ?>
        </tbody>
    </table>
</div>
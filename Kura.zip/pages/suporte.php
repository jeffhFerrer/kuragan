<style>
    .label {
        width: 100%;
        font-weight: 900 !important;
        text-align: center;
        border: 3px solid #fff !important;
        border-radius: 10px;
        color: #1b1b1b;
        background: #fff;
        padding: 7px;
    }

    .label:hover {
        color: #fff !important;
        background: #000924 !important;
    }
</style>
<main class="container">
    <h3 class="mt-5">Entre em Contato Conosco</h3>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="nome">Nome: *</label>
            <input type="text" class="form-control" id="nome" name="nome" required>
        </div>
        <div class="form-group">
            <label for="email">Email: *</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="assunto">Assunto: *</label>
            <input type="text" class="form-control" id="assunto" name="assunto" required>
        </div>
        <div class="form-group">
            <label for="mensagem">Mensagem: *</label>
            <textarea class="form-control" id="mensagem" name="mensagem" rows="4" required></textarea>
        </div>
        <div class="form-group">
            <label class="label" for="imagem">Selecione uma Imagem</label>
            <input hidden type="file" class="form-control-file" id="imagem" name="imagem" accept="image/*">
        </div>
        <button type="submit" name="enviar_suporte" class="btn btn-primary">Enviar Mensagem</button>
    </form>
    <?php
    date_default_timezone_set('America/Fortaleza');

    include_once('conect/conexao.php');

    if (isset($_POST["enviar_suporte"])) {
        // O botão "enviar_suporte" foi clicado
    
        $nome = $_POST["nome"];
        $email = $_POST["email"];
        $assunto = $_POST["assunto"];
        $mensagem = $_POST["mensagem"];

        // Processar a imagem enviada
        $imagem_nome = $_FILES["imagem"]["name"];
        $imagem_tmp = $_FILES["imagem"]["tmp_name"];
        $pasta_destino = "suporte/"; // Pasta onde as imagens serão armazenadas
        $imagem_caminho = $pasta_destino . $imagem_nome;

        // Mova a imagem para a pasta de destino
        move_uploaded_file($imagem_tmp, $imagem_caminho);

        // Obtenha a data e hora de envio
        $data_envio = date('Y-m-d H:i:s');

        // Prepare a consulta SQL para inserir os dados na tabela
        $sql = "INSERT INTO mensagens_suporte (nome, email, assunto, mensagem, imagem, data_envio) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $nome, $email, $assunto, $mensagem, $imagem_caminho, $data_envio);

        // Execute a consulta
        if ($stmt->execute()) {
            // Mensagem armazenada com sucesso
            echo 'mensagem enviada com sucesso';
            echo '<script>
                    setTimeout(function() {
                        window.location.href = "index.php?acao=suporte";
                    }, 2000); // Redirecionar após 2 segundos
                </script>';

            exit();
        } else {
            // Erro ao armazenar a mensagem
            die("Erro ao armazenar a mensagem: " . $stmt->error);
        }
    } else {
        // Outro botão de envio foi clicado ou nenhum botão foi clicado
        // Adicione aqui o tratamento para outros botões, se necessário
    }
    ?>
</main>
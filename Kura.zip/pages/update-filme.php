<?php
include_once('conect/conexao.php');

$message = "";

// Função para gerar um nome de arquivo único
function generateUniqueFileName($originalName)
{
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $uniqueName = uniqid() . '.' . $extension;
    return $uniqueName;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update"])) {
    $filmeId = $_POST["filme_id"];
    $titulo = ($_POST["titulo"]);
    $descricao = ($_POST["descricao"]);
    $genero = ($_POST["genero"]);
    $classificacao = ($_POST["classificacao"]);

    // Verificar se o usuário deseja alterar a capa
    $uploadCapaPath = $_POST["capa_atual"];
    if (!empty($_FILES["capa"]["name"])) {
        if (!empty($uploadCapaPath)) {
            unlink($uploadCapaPath);
        }
        $capaName = generateUniqueFileName($_FILES["capa"]["name"]);
        $capaTmp = $_FILES["capa"]["tmp_name"];
        $uploadCapaPath = "assets/video/capa/" . $capaName;
        move_uploaded_file($capaTmp, $uploadCapaPath);
    }

    // Verificar se o usuário deseja alterar o post
    $uploadPostsPath = $_POST["posts_atual"];
    if (!empty($_FILES["posts"]["name"])) {
        if (!empty($uploadPostsPath)) {
            unlink($uploadPostsPath);
        }
        $postsName = generateUniqueFileName($_FILES["posts"]["name"]);
        $postsTmp = $_FILES["posts"]["tmp_name"];
        $uploadPostsPath = "assets/video/posts/" . $postsName;
        move_uploaded_file($postsTmp, $uploadPostsPath);
    }

    // Verificar se o usuário deseja alterar o vídeo
    $uploadVideoPath = $_POST["video_atual"];
    if ($_POST["uploadOption"] === "upload") {
        if (!empty($_FILES["videoFile"]["name"])) {
            if (!empty($uploadVideoPath)) {
                unlink($uploadVideoPath);
            }
            $videoName = generateUniqueFileName($_FILES["videoFile"]["name"]);
            $videoTmp = $_FILES["videoFile"]["tmp_name"];
            $uploadVideoPath = "uploads/" . $videoName;
            move_uploaded_file($videoTmp, $uploadVideoPath);
        }
    } elseif ($_POST["uploadOption"] === "url") {
        if (!empty($_FILES["videoFile"]["name"])) {
            if (!empty($uploadVideoPath)) {
                unlink($uploadVideoPath);
            }
        }
        $videoURL = ($_POST["videoURL"]);
        $uploadVideoPath = $videoURL;
    }

    // Atualizar os dados no banco de dados
    $sql = "UPDATE tb_video SET title=?, descricao=?, genero=?, classificacao=?, capa=?, posts=?, url=? WHERE video_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssi", $titulo, $descricao, $genero, $classificacao, $uploadCapaPath, $uploadPostsPath, $uploadVideoPath, $filmeId);

    if ($stmt->execute()) {
        $message = '<div id="ok-sucess">Filme atualizado com sucesso!</div>';
    } else {
        $message = '<div id="no-sucess">Erro ao atualizar o filme.</div>';
    }

    $stmt->close();
}
?>
<?php
$filmeId = $_GET["video_id"];
$sql = "SELECT * FROM tb_video WHERE video_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $filmeId);
$stmt->execute();
$result = $stmt->get_result();
$filme = $result->fetch_assoc();
$stmt->close();
?>
<main class="container my-4">
    <h2 class="mb-4">Upload e Informações de Filmes</h2>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <input type="radio" name="uploadOption" value="upload" id="uploadOption" checked>
            <label for="uploadOption">Upload de Vídeo</label><br>

            <input type="radio" name="uploadOption" value="url" id="urlOption">
            <label for="urlOption">Link URL do Vídeo</label><br>
        </div>

        <div id="uploadSection">
            <div class="form-group">
                <label for="videoFile">Vídeo:</label>
                <div class="custom-file">
                    <input class="custom-file-input" type="file" name="videoFile" id="videoFile" accept="video/*">
                    <label class="custom-file-label" for="videoFile">Escolha um arquivo de vídeo</label>
                </div>
            </div>
        </div>

        <div id="urlSection" style="display: none;">
            <div class="form-group">
                <label for="videoURL">URL</label>
                <input class="form-control" type="text" name="videoURL" id="videoURL" placeholder="URL do Vídeo">
            </div>
        </div>
        <script>
            const uploadOption = document.getElementById('uploadOption');
            const urlOption = document.getElementById('urlOption');
            const uploadSection = document.getElementById('uploadSection');
            const urlSection = document.getElementById('urlSection');

            uploadOption.addEventListener('change', () => {
                uploadSection.style.display = 'block';
                urlSection.style.display = 'none';
            });

            urlOption.addEventListener('change', () => {
                uploadSection.style.display = 'none';
                urlSection.style.display = 'block';
            });
        </script>
        <div class="form-group">
            <label for="capa">Capa do Vídeo:</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="capa" name="capa" accept="image/*">
                <label class="custom-file-label" for="capa">Escolha um arquivo de imagem</label>
            </div>
        </div>

        <div class="form-group">
            <label for="posts">Post de Apresentação (1110x500):</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="posts" name="posts" accept="image/*">
                <label class="custom-file-label" for="posts">Escolha um arquivo de imagem</label>
            </div>
        </div>

        <div class="form-group">
            <label for="classificacao">Classificação Indicativa:</label>
            <select class="form-control" id="classificacao" name="classificacao">
                <option value="<?php echo $filme['classificacao']; ?>"><?php echo $filme['classificacao']; ?></option>
                <option value="Livre">Livre</option>
                <option value="10+">10+</option>
                <option value="12+">12+</option>
                <option value="14+">14+</option>
                <option value="16+">16+</option>
                <option value="18+">18+</option>
            </select>
        </div>


        <div class="form-group">
            <label for="titulo">Título:</label>
            <input type="text" class="form-control" name="titulo" value="<?php echo $filme['title']; ?>">
        </div>

        <div class="form-group">
            <label for="descricao">Descrição:</label>
            <textarea class="form-control" name="descricao" rows="4"><?php echo $filme['descricao']; ?></textarea>
        </div>

        <div class="form-group">
            <label for="genero">Gênero:</label>
            <input type="text" class="form-control" name="genero" value="<?php echo $filme['genero']; ?>">
        </div>

        <input type="hidden" name="filme_id" value="<?php echo $filme['video_id']; ?>">
        <input type="hidden" name="capa_atual" value="<?php echo $filme['capa']; ?>">
        <input type="hidden" name="posts_atual" value="<?php echo $filme['posts']; ?>">
        <input type="hidden" name="video_atual" value="<?php echo $filme['url']; ?>">

        <button type="submit" class="btn btn-primary" name="update">Enviar Vídeo</button>
    </form>
    <?php echo $message; ?>
</main>
<?php
include('../conect/conexao.php');
session_start();

// Verifica se o método de requisição é POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Verifica se o usuário está logado
    if (isset($_SESSION['user_id'])) {
        $comment_text = $_POST["comment_text"];
        if (!empty($comment_text)) {
            $user_id = $_SESSION['user_id'];
            $video_id = $_GET['video_id']; // Adicione o campo oculto no formulário com o ID do vídeo

            // Prepare a instrução SQL para inserir o comentário
            $sql = "INSERT INTO tb_coment (user_id, video_id, comment_text) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iis", $user_id, $video_id, $comment_text);

            if ($stmt->execute()) {
                // Comentário inserido com sucesso
                echo json_encode(['success' => true]);
                exit;
            } else {
                // Erro ao inserir o comentário
                echo json_encode(['success' => false, 'message' => 'Erro ao inserir o comentário']);
                exit;
            }
        } else {
            // O campo de comentário está vazio
            echo json_encode(['success' => false, 'message' => 'O campo de comentário está vazio']);
            exit;
        }
    } else {
        // O usuário não está logado
        echo json_encode(['success' => false, 'message' => 'Usuário não logado']);
        exit;
    }
} else {
    // Método de requisição inválido
    echo json_encode(['success' => false, 'message' => 'Método de requisição inválido']);
    exit;
}
?>
<style>
    form,
    table {
        margin: 15px;
    }

    h1,
    h2,
    h3,
    h4,
    h5 {
        color: #ff6600;
        background-color: #7777771b;
        padding: 10px;
        margin: 0;
        margin: 0 15px 0 15px;
        text-align: center;
        border-radius: 10px;

    }

    label {
        font-weight: bold;
        margin: 15px 0 15px 0;
    }

    select,
    textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #dddddd;
        background-color: transparent;
        color: #ffffff;
        border-radius: 10px
    }

    select {
        height: 40px;
    }

    textarea {
        height: 150px;
    }

    #env {
        padding: 10px 20px;
        background-color: #ff6600;
        color: #ffffff;
        border: none;
        cursor: pointer;
        border-radius: 10px
    }

    #env:hover {
        background-color: #ff8533;
    }

    table {
        border: 1px solid #dee2e6;
    }

    table th {
        background-color: #343a40;
        color: #fff;
        font-weight: bold;
        font-size: 16px;
        border: none;
        text-align: center;
        padding: 10px;
    }

    table td {
        vertical-align: middle;
        text-align: center;
        color: #fff;
        padding: 10px;
        border: 1px solid #dee2e6;
        overflow: elipsis;
        max-width: 200px;
        /* Ajuste conforme necessário */
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>

<?php
include('conect/conexao.php');
date_default_timezone_set('America/Fortaleza');

$dataatualhj = date('d/m');
?>


<h1>Criar Notificação</h1>
<form method="POST">
    <label for="selected_criteria">Critério:</label>
    <select name="selected_criteria" id="selected_criteria">
        <!-- Opções de critérios aqui -->
        <option value="tipo_user = '2'">Usuários (ADM)</option>
        <option value="DATE_FORMAT(STR_TO_DATE(data_nascimento, '%d/%m/%Y'), '%d/%m') = '<?php echo $dataatualhj ?>'">
            Aniversariantes do
            dia</option>
    </select>
    <br>
    <label for="message_type">Tipo de Mensagem:</label>
    <select name="message_type" id="message_type">
        <option value="predefined">Mensagem Pronta</option>
        <option value="manual">Digitar Manualmente</option>
        <option value="birthday">Mensagem de Aniversário</option>
        <option value="promotion">Mensagem de Promoção</option>
        <!-- Adicione mais opções de mensagens prontas aqui -->
    </select>
    <br>
    <div id="predefined_message_options" class="hidden">
        <!-- Opções de mensagens prontas aqui -->
    </div>
    <label style="display: none;" for="mensagem" id="manual_message_label">Mensagem:</label>
    <textarea style="display: none;" name="mensagem" id="mensagem" rows="4" cols="50" class="hidden"></textarea>
    <br>
    <button id="env" type="submit" name="criar_notificacoes">Criar Notificações</button>
</form>
<!-- Tabela de critérios e usuários -->
<table>
    <tr>
        <th>Critério</th>
        <th>Usuários</th>
    </tr>
    <?php

    // Defina os critérios que deseja exibir
    $critérios = array(
        "tipo_user = '2'" => "Usuários (ADM)",
        "DATE_FORMAT(STR_TO_DATE(data_nascimento, '%d/%m/%Y'), '%d/%m') = '" . $dataatualhj . "'" => "Aniversariantes",
        // Adicione mais critérios aqui
    );


    foreach ($critérios as $criterioSQL => $criterioNome) {
        $sql_users = "SELECT user_id FROM tb_user WHERE $criterioSQL";
        $result_users = mysqli_query($conn, $sql_users);
        $quantidade_usuarios = mysqli_num_rows($result_users);

        echo "<tr>";
        echo "<td>$criterioNome</td>";
        echo "<td>$quantidade_usuarios</td>";
        echo "</tr>";
    }
    ?>
</table>

<script>
    const messageSelect = document.getElementById('message_type');
    const predefinedOptions = document.getElementById('predefined_message_options');
    const manualMessageLabel = document.getElementById('manual_message_label');
    const manualMessageTextarea = document.getElementById('mensagem');

    messageSelect.addEventListener('change', function () {
        if (messageSelect.value === 'predefined') {
            predefinedOptions.style.display = 'block';
            manualMessageLabel.style.display = 'none';
            manualMessageTextarea.style.display = 'none';
        } else if (messageSelect.value === 'manual') {
            predefinedOptions.style.display = 'none';
            manualMessageLabel.style.display = 'block';
            manualMessageTextarea.style.display = 'block';
        }
    });

</script>

<?php
if (isset($_POST['criar_notificacoes'])) {
    $selected_criteria = $_POST['selected_criteria'];
    $message_type = $_POST['message_type'];
    $data = date('Y-m-d H:i:s');

    $sql_users = "SELECT * FROM tb_user WHERE $selected_criteria";
    $result_users = mysqli_query($conn, $sql_users);

    if ($result_users) {
        while ($user_row = mysqli_fetch_assoc($result_users)) {
            $user_id = $user_row['user_id'];
            $nome_usuario = $user_row['username'];
            $data_nascimento = $user_row['data_nascimento'];

            // Inicialize a mensagem comum
            $mensagem_inserida = "";

            // Verifique o tipo de mensagem
            if ($message_type === 'birthday') {
                // Mensagem de aniversário com quebra de linha
                $mensagem_inserida = "Feliz Aniversário, $nome_usuario!\n\n"
                    . "Hoje é o seu dia especial, e desejamos a você um aniversário repleto de alegria, amor e realizações. Que este novo ano de vida seja cheio de sucesso, saúde e momentos inesquecíveis. \n\nSua diversidade e unicidade enriquecem nossa comunidade. Celebre e aproveite este dia ao máximo, sabendo que somos gratos por ter você conosco. \n\nContinue compartilhando sua paixão por filmes e entretenimento conosco, pois esperamos muitas mais aventuras juntos. \n\nTenha um dia incrível, e um ano cheio de felicidade e prosperidade!\n\n"
                    . "Com carinho,\nEquipe Kuragan";
            } elseif ($message_type === 'promotion') {
                // Mensagem de promoção
                $mensagem_inserida = "Parabéns pela promoção, $nome_usuario!\n\n"
                    . "Estamos muito felizes em reconhecer suas conquistas e dedicação. Sua jornada conosco é incrível, e a promoção é apenas o começo de mais sucessos. Continue brilhando e inspirando todos nós!\n\n"
                    . "Comemore este marco e saiba que estamos orgulhosos de tê-lo em nossa equipe.\n\n"
                    . "Com carinho,\nEquipe Kuragan.";
            } elseif ($message_type === 'manual') {
                $mensagem_inserida = $_POST['mensagem'];
            }
            // Escapar a mensagem
            $mensagem_inserida = mysqli_real_escape_string($conn, $mensagem_inserida);

            $sql_insert = "INSERT INTO tb_notificacoes (user_id, mensagem, data) VALUES ($user_id, '$mensagem_inserida', '$data')";
            mysqli_query($conn, $sql_insert);
        }

        echo '<div id="ok-sucess"> Notificações inseridas com sucesso!</div>';
    } else {
        echo "Erro ao obter usuários: " . mysqli_error($conn);
    }
}
?>
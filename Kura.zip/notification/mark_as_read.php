<?php
// mark_as_read.php
if (isset($_GET['id'])) {
    $notificationId = $_GET['id'];

    include_once('../conect/conexao.php');

    // Atualize o campo "lida" para 1
    $query = "UPDATE tb_notificacoes SET lida = 1 WHERE id = $notificationId";

    if ($conn->query($query) === TRUE) {
        echo "Marcação como lida realizada com sucesso!";
    } else {
        echo "Erro ao marcar como lida: " . $conn->error;
    }

    $conn->close();
}
?>
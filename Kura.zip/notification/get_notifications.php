<?php
session_start();
include_once('../conect/conexao.php');

// Consulta SQL para buscar notificações do usuário atual (supondo que você tenha um sistema de autenticação)
$user_id = $_SESSION["user_id"]; // Substitua pelo ID do usuário logado
$query = "SELECT * FROM tb_notificacoes WHERE user_id = $user_id ORDER BY id DESC";

$result = $conn->query($query);

if ($result->num_rows === 0) {
    echo '<p class="notification">Nenhuma notificação encontrada para o usuário.</p>';
} else {
    while ($row = $result->fetch_assoc()) {
        $statusIcon = $row['lida'] == 1 ? '✓' : '✉';

        echo '<div class="notification">';
        echo '<p class="timestamp">' . $statusIcon . date("d/m/Y H:i", strtotime($row['data'])) . '</p>';
        echo '<p>' . nl2br($row['mensagem']) . '</p>'; // Usar nl2br para converter quebras de linha em <br>
        echo '<div id="area-notify">';
        if ($row['lida'] == 0) {
            echo '<button onclick="markAsRead(' . $row['id'] . ')"><i class="fas fa-check"></i></button>';
        }
        echo '<button onclick="deleteNotification(' . $row['id'] . ')"><i class="fas fa-trash-alt"></i></button>'; // Botão de remoção
        echo '</div>';
        echo '</div>';
    }
}
?>
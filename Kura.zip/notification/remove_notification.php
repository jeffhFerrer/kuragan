<?php
// delete_notification.php
if (isset($_GET['id'])) {
    $notificationId = $_GET['id'];

    include_once('../conect/conexao.php');

    // Execute uma consulta SQL para remover a notificação com base no ID
    $query = "DELETE FROM tb_notificacoes WHERE id = $notificationId";

    if ($conn->query($query) === TRUE) {
        echo "Removida com sucesso!";
    } else {
        echo "Erro ao remover: " . $conn->error;
    }

    $conn->close();
}
?>
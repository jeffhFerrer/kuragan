<style>
    h4 {
        background-color: #7777771b;
        color: white;
        padding: 10px;
        margin: 0;
        margin: 0 15px 0 15px;
        text-align: center;
    }

    #notifications {
        margin: 15px;
        padding: 20px;
        background-color: #7777771b;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        border-radius: 5px;
    }

    .notification {
        padding: 10px;
        border-bottom: 1px solid #ddd;
    }

    .notification p {
        margin: 0;
        padding: 5px 0;
    }

    .timestamp {
        color: #999;
    }
    #area-notify{
        width: 100px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .notification button {
        background-color: #e74c3c;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 100%;
        cursor: pointer;
        outline: none;
        border: 1px solid #fff;
    }

    .notification button:hover {
        background-color: #c0392b;
    }
</style>
<h4>Área de Notificações</h4>
<div id="notifications"></div>

<script>
    function getNotifications() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'notification/get_notifications.php', true);

        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    document.getElementById('notifications').innerHTML = xhr.responseText;
                }
            }
        };

        xhr.send();
    }

    function markAsRead(notificationId) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'notification/mark_as_read.php?id=' + notificationId, true);

        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    getNotifications(); // Atualizar lista após marcar como lida
                }
            }
        };

        xhr.send();
    }

    function deleteNotification(notificationId) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'notification/remove_notification.php?id=' + notificationId, true);

        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    getNotifications(); // Atualizar lista após marcar como lida
                }
            }
        };

        xhr.send();
    }


    setInterval(getNotifications, 10000);
    getNotifications(); // Carregar notificações inicialmente
</script>
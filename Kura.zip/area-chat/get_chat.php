<?php
session_start();
include_once('../conect/conexao.php');
$conversation_id = $_GET['conversation_id'];

// Verifique se a variável de sessão 'conversation_id' está definida
if (!isset($_GET['conversation_id'])) {
    echo 'Conversa não especificada.';
    exit();
}

// Obtém o ID da conversa a partir da variável de sessão
$conversation_id = $_GET['conversation_id'];

// Consulta para obter as mensagens da conversa especificada
$sql = "SELECT m.*, u.username AS remetente_nome, u.foto AS remetente_foto
        FROM tb_messages AS m
        INNER JOIN tb_user AS u ON m.remetente_id = u.user_id
        WHERE m.conversa_id = $conversation_id
        ORDER BY m.id ASC";

$result = $conn->query($sql);
?>
<!-- Seu código HTML para a exibição das mensagens aqui -->
<?php
// Exibe as mensagens da consulta
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row["remetente_id"] == $_SESSION["user_id"]) {
            // Esta é uma mensagem do remetente
            echo '<div class="message minha-mensagem">';
            echo '<div class="message-details">';
            echo '<div class="message-info">';
            echo '<span class="user-name">' . $row["remetente_nome"] . '</span></br>';
            echo '<span class="message-time">' . date('d/m/Y H:i:s', strtotime($row['timestamp'])) . '</span>';
            echo '</div>';
            echo '<img src="../assets/user/' . $row["remetente_foto"] . '" alt="Foto do Usuário">';
            echo '</div>';
            echo '<div class="message-content">' . nl2br($row["mensagem"]) . '</div>';
            echo '</div>';
        } else {
            // Esta é uma mensagem de outro usuário
            echo '<div class="message outra-mensagem">';
            echo '<div class="message-details">';
            echo '<img src="../assets/user/' . $row["remetente_foto"] . '" alt="Foto do Usuário">';
            echo '<div class="message-info">';
            echo '<span class="user-name">' . $row["remetente_nome"] . '</span></br>';
            echo '<span class="message-time">' . date('d/m/Y H:i:s', strtotime($row['timestamp'])) . '</span>';
            echo '</div>';
            echo '</div>';
            echo '<div class="message-content">' . nl2br($row["mensagem"]) . '</div>';
            echo '</div>';
        }
    }
} else {
    echo "Nenhuma mensagem encontrada.";
}
?>
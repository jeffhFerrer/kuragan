<link rel="stylesheet" href="../chat/estilo/style.css">
<?php
include_once('../conect/conexao.php');
date_default_timezone_set('America/Fortaleza');

// Verifique se o usuário está logado ou redirecione para a página de login, se necessário
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php"); // Substitua 'login.php' pelo URL da sua página de login
    exit();
}

// Função para obter mensagens de uma conversa específica
function getMessagesForConversation($conversation_id, $conn)
{
    $user_id = $_SESSION['user_id']; // ID do usuário atual
    $sql = "SELECT m.*, u.username
            FROM tb_messages AS m
            JOIN tb_user AS u ON m.remetente_id = u.user_id
            WHERE m.conversa_id = $conversation_id
            ORDER BY m.timestamp ASC";
    $result = $conn->query($sql);
    $messages = [];

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
    }

    return $messages;
}

// Verifique se o parâmetro conversation_id foi passado na URL
if (isset($_GET['conversation_id'])) {
    $conversation_id = $_GET['conversation_id'];

    // Lógica para verificar se o usuário tem acesso a esta conversa (implemente conforme necessário)
    // Certifique-se de verificar se o usuário atual tem permissão para acessar esta conversa

    // Obtém as mensagens da conversa
    $messages = getMessagesForConversation($conversation_id, $conn);
} else {
    echo 'Conversa não especificada.';
}
?>
<?php
$user_idR = $_SESSION['user_id'];
$select = "SELECT * FROM tb_conversas WHERE id = $conversation_id AND remetente_id = $user_idR";
$chat_result = $conn->query($select);
if ($chat_result->num_rows > 0) {
    $chat_row = $chat_result->fetch_assoc();
    $destinatario = $chat_row["destinatario_id"];
    $remetente = $chat_row["remetente_id"];

}
?>

<style>
    .minha-mensagem {
        background-color: #e2f7fc;
        /* Cor de fundo para mensagens do usuário */
        color: #333;
        /* Cor do texto */
        align-self: flex-end !important;
        /* Alinha as mensagens do usuário à direita */
        margin-left: auto;
        /* Margem à esquerda para mensagens do usuário */

    }

    .minha-mensagem .message-details {
        text-align: end;
        width: 100%;
        justify-content: flex-end !important;

    }

    .minha-mensagem .message-content {
        width: 100%;
        text-align: end;
    }

    .outra-mensagem {
        background-color: #7777771b;
        /* Cor de fundo para mensagens de outros usuários */
        color: #fff;
        /* Cor do texto */
        align-self: flex-start !important;
        /* Alinha as mensagens de outros usuários à esquerda */
        margin-right: auto;
        /* Margem à direita para mensagens de outros usuários */
    }
</style>
<div class="container mt-5">
    <div class="chat-messages" id="chatContainer"></div>
    <script>
        function getChat() {
            var conversation_id = <?php echo $_GET['conversation_id']; ?>; // Recupera o valor do PHP
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '../area-chat/get_chat.php?conversation_id=' + conversation_id, true); // Passa o valor na URL

            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        document.getElementById('chatContainer').innerHTML = xhr.responseText;
                    }
                }
            };

            xhr.send();
        }

        setInterval(getChat, 2000);
        getChat(); // Carregar notificações inicialmente
    </script>
    <!-- Formulário para enviar mensagens -->
    <?php
    $user_idR = $_SESSION['user_id'];
    $conversation_id = $_GET['conversation_id'];

    $select = "SELECT * FROM tb_conversas WHERE id = $conversation_id AND (remetente_id = $user_idR OR destinatario_id = $user_idR)";
    $chat_result = $conn->query($select);

    if ($chat_result->num_rows > 0) {
        $chat_row = $chat_result->fetch_assoc();
        $remetente_id = $chat_row["remetente_id"];
        $destinatario_id = $chat_row["destinatario_id"];

        // Verifica se o usuário logado é o remetente e troca o destinatário se necessário
        if ($remetente_id == $user_idR) {
            // O usuário logado é o remetente, portanto, o destinatário será o destinatário original
        } else {
            // O usuário logado é o destinatário, então troque os papéis
            $temp = $remetente_id;
            $remetente_id = $destinatario_id;
            $destinatario_id = $temp;
        }
    }
    ?>
    <form action="" method="post" class="input-container" style="border-radius: 0 !important;">
        <input hidden type="text" name="conversation_id" id="conversation_id"
            value="<?php echo $_GET['conversation_id']; ?>"><br>
        <input hidden type="text" name="destinatario_id" id="destinatario_id"
            value="<?php echo $destinatario_id; ?>"><br>
        <div class="input-group mb-3">
            <textarea name="mensagem" id="messageInput" rows="1"></textarea>
            <div class="input-group-append">
                <button style="width:70px !important; height:70px !important; border-top-right-radius: 0 !important;"
                    class="btn btn-primary" type="submit" id="sendButton"><i class="fas fa-paper-plane"></i></button>
            </div>
        </div>
    </form>
    <?php
    include_once('../conect/conexao.php');

    // Verifique se o usuário está logado ou redirecione para a página de login, se necessário
    if (!isset($_SESSION['user_id'])) {
        header("../Location: login.php"); // Substitua 'login.php' pelo URL da sua página de login
        exit();
    }

    if (isset($_POST['mensagem']) && !empty($_POST['mensagem'])) {
        $conversation_id = $_POST["conversation_id"];
        $mensagem = $_POST["mensagem"];
        $remetente_id = $_SESSION["user_id"]; // Suponha que você tenha a sessão do usuário logado
        $destinatario_id = $_POST["destinatario_id"]; // Suponha que você tenha uma forma de determinar o destinatário
    
        // Defina o timestamp atual
        $timestamp = date('Y-m-d H:i:s');

        // Defina 'is_read' como 0 (não lida) por padrão
        $is_read = 0;

        // Inserir a mensagem no banco de dados
        $sql_inserir_mensagem = "INSERT INTO tb_messages (conversa_id, remetente_id, destinatario_id, mensagem, timestamp, is_read) VALUES ('$conversation_id', '$remetente_id', '$destinatario_id', '$mensagem', '$timestamp', '$is_read')";

        if ($conn->query($sql_inserir_mensagem) === TRUE) {
            // A mensagem foi inserida com sucesso
        } else {
            echo "Erro ao enviar a mensagem: contate nossos desenvolvedores"; //. $conn->error;
        }
    } else {

    }
    ?>
</div>
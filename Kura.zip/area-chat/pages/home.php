<div class="container mt-5">
    <style>
        #img_outro_user{
            width: 50px;
            height: 50px;
            border: 3px solid #000924;
            border-radius: 100%;
            padding: 0;
            object-fit: cover;
            max-height: 50px;
            max-width: 50px;
            min-height: 50px;
            min-width: 50px;
            margin-right: 5px;
        }
        .list-group-item{
            padding: 3px !important;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .list-group-item a{
            width: 100%;
            color: #000924;
            font-weight: 900;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-decoration: none;
        }
    </style>
    <div class="row">
        <!-- Coluna para iniciar uma nova conversa -->
        <div class="col-md-8">
            <p style='width: 100%; text-transform:uppercase; font-size:20px;'>Iniciar Nova Conversa</p>
            <form action="" method="post">
                <div class="input-group mb-3">
                    <input type="text" name="chave_unica" class="form-control" placeholder="Insira a Chave Única"
                        aria-label="Insira a Chave Única" aria-describedby="iniciar-conversa">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit"><i class="fas fa-paper-plane"></i>
                            Iniciar</button>
                    </div>
                </div>
            </form>
            <?php
            include_once('../conect/conexao.php');

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $chave_unica = $_POST["chave_unica"];
                $remetente_id = $_SESSION["user_id"]; // ID do usuário logado
            
                // Verificar a qual usuário a chave única pertence
                $sql_verificar_usuario = "SELECT user_id FROM tb_user WHERE chave_unica = '$chave_unica'";
                $result_verificar_usuario = $conn->query($sql_verificar_usuario);

                if ($result_verificar_usuario->num_rows > 0) {
                    $row = $result_verificar_usuario->fetch_assoc();
                    $destinatario_id = $row["user_id"];

                    // Verificar se o destinatário é o mesmo que o remetente
                    if ($destinatario_id == $remetente_id) {
                        echo "Você não pode criar uma conversa com você mesmo.";
                    } else {
                        // Verificar se uma conversa entre remetente e destinatário já existe
                        $sql_verificar_conversa = "SELECT id FROM tb_conversas WHERE ((remetente_id = $remetente_id AND destinatario_id = $destinatario_id) OR (remetente_id = $destinatario_id AND destinatario_id = $remetente_id))";
                        $result_verificar_conversa = $conn->query($sql_verificar_conversa);

                        if ($result_verificar_conversa->num_rows > 0) {
                            // A conversa já existe, redirecione o usuário para ela
                            $row = $result_verificar_conversa->fetch_assoc();
                            $conversa_id = $row["id"];
                            echo '<script>window.location.href = "index.php?acao=chat&conversation_id=' . $conversa_id . '";</script>';
                            exit();
                        } else {
                            // A conversa não existe, crie uma nova conversa no banco de dados
                            $sql_inserir_conversa = "INSERT INTO tb_conversas (remetente_id, destinatario_id) VALUES ($remetente_id, $destinatario_id)";
                            if ($conn->query($sql_inserir_conversa) === TRUE) {
                                $nova_conversa_id = $conn->insert_id;

                                // Redireciona o usuário para a conversa recém-criada
                                echo '<script>window.location.href = "index.php?acao=chat&conversation_id=' . $nova_conversa_id . '";</script>';
                                exit();
                            } else {
                                echo "Erro ao criar a conversa: " . $conn->error;
                            }
                        }
                    }
                } else {
                    // A chave única não está associada a nenhum usuário, exiba uma mensagem de erro
                    echo "Chave única inválida. Verifique e tente novamente.";
                }
            }
            ?>
        </div>
        <!-- Coluna para listar as conversas existentes -->
        <div class="col-md-8">
            <p style='width: 100%; text-transform:uppercase; font-size:20px;'>Conversas Existentes</p>
            <ul class="list-group">
                <!-- Lógica PHP para listar as conversas existentes -->
                <?php
                include_once('../conect/conexao.php');
                $envUser = $_SESSION['user_id'];

                $sql = "SELECT c.id, c.remetente_id, c.destinatario_id, u.username AS outro_usuario, foto AS img_outro_user
                FROM tb_conversas AS c
                LEFT JOIN tb_user AS u ON
                (c.remetente_id = u.user_id AND c.destinatario_id = $envUser) OR
                (c.destinatario_id = u.user_id AND c.remetente_id = $envUser)
                WHERE c.remetente_id = $envUser OR c.destinatario_id = $envUser";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $conversation_id = $row["id"];
                        $conversation_name = $row["outro_usuario"];
                        $conversation_ft = $row['img_outro_user'];
                        echo '<li class="list-group-item"><a href="index.php?acao=chat&conversation_id=' . $conversation_id . '"><img id="img_outro_user"src="../assets/user/' . $conversation_ft . ' " alt=" '. $conversation_ft .' ">' . $conversation_name . '</a></li>';
                    }
                } else {
                    echo 'Nenhuma conversa encontrada.';
                }
                ?>

            </ul>
        </div>

    </div>
</div>
<?php
// Inclui o cabeçalho do site
include_once('includes/header.php');

// Defina as páginas e suas correspondentes ações
$paginas = array(
    'home' => 'pages/home.php',
    'chat' => 'pages/chat.php',
    'erro' => '../pages/erro.php'
    // Adicione mais páginas conforme necessário
);

// Obtém o valor da ação da URL ou define como 'home' por padrão
$acao = isset($_GET['acao']) ? $_GET['acao'] : 'home';

// Verifica se a página está definida no array, caso contrário, define como 'erro'
if (!array_key_exists($acao, $paginas)) {
    $acao = 'erro';
}


// Define o caminho completo para o arquivo da página com base na ação
$caminhoPagina = $paginas[$acao];

// Inclui a página correspondente
include_once($caminhoPagina);

// Inclui o rodapé do site
include_once('includes/footer.php');
?>
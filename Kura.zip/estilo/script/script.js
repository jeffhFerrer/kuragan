const video = document.getElementById('video');
const playPauseButton = document.getElementById('play-pause-button');
const muteButton = document.getElementById('mute-button');
const skipBackButton = document.getElementById('skip-back-button');
const skipForwardButton = document.getElementById('skip-forward-button');
const restartButton = document.getElementById('restart-button');
const progress = document.querySelector('#progress');
const volumeValue = document.getElementById("volume-value");
const timer = document.getElementById("timer");
const fullscreenButton = document.getElementById("fullscreen-button");
const volumeUpArea = document.querySelector(".volume-touch-area.up");
const volumeDownArea = document.querySelector(".volume-touch-area.down");
const muteButtonIcon = document.querySelector("#mute-button i");
const customControls = document.querySelector(".custom-controls");
const customControls2 = document.querySelector(".custom-controls-2");

let touchStartX = 0;
let touchEndX = 0;
let controlsTimeout;

function updateProgressBar() {
    const currentTime = video.currentTime;
    const duration = video.duration;
    const progressPercentage = (currentTime / duration) * 100;
    progress.value = progressPercentage;

    const currentMinutes = Math.floor(currentTime / 60);
    const currentSeconds = Math.floor(currentTime % 60);
    const durationMinutes = Math.floor(duration / 60);
    const durationSeconds = Math.floor(duration % 60);

    timer.textContent = `${currentMinutes}:${currentSeconds} / ${durationMinutes}:${durationSeconds}`;
}

function seek(event) {
    const offsetX = event.offsetX;
    const progressBarWidth = progress.offsetWidth;
    const seekTime = (offsetX / progressBarWidth) * video.duration;
    video.currentTime = seekTime;
}

function togglePlayPause() {
    if (video.paused) {
        video.play();
        playPauseButton.innerHTML = '<i class="fas fa-pause"></i>';
    } else {
        video.pause();
        playPauseButton.innerHTML = '<i class="fas fa-play"></i>';
    }
}

function skipForward() {
    video.currentTime += 10;
}

function skipBackward() {
    video.currentTime -= 10;
}

function toggleMute() {
    video.muted = !video.muted;
    muteButton.innerHTML = video.muted ? '<i class="fas fa-volume-mute"></i>' : '<i class="fas fa-volume-up"></i>';
}

function updateVolumeTextAndIcon() {
    const volumePercentage = Math.round(video.volume * 100);
    volumeValue.textContent = `${volumePercentage}%`;

    if (video.volume === 0) {
        muteButtonIcon.className = "fas fa-volume-mute";
    } else {
        muteButtonIcon.className = "fas fa-volume-up";
    }
}

function toggleFullscreen() {
    if (document.fullscreenElement) {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        }
    } else {
        if (video.requestFullscreen) {
            video.requestFullscreen();
        }
    }
}

function hideControls() {
    customControls.style.opacity = 0;
    customControls2.style.opacity = 0;
}

function showControls() {
    customControls.style.opacity = 1;
    customControls2.style.opacity = 1;
    clearTimeout(controlsTimeout);
    controlsTimeout = setTimeout(hideControls, 5000);
}

function handleVideoKeyPress(event) {
    const key = event.key;

    if (key === " ") {
        event.preventDefault();
        togglePlayPause();
    } else if (key === "ArrowRight") {
        event.preventDefault();
        skipForward();
    } else if (key === "ArrowLeft") {
        event.preventDefault();
        skipBackward();
    } else if (key === "m") {
        event.preventDefault();
        toggleMute();
    } else if (key === "f") {
        event.preventDefault();
        toggleFullscreen();
    } else if (key === "ArrowUp") {
        event.preventDefault();
        
        if (video.volume < 1) {
            video.volume += 0.1;
        }
        updateVolumeTextAndIcon();
    } else if (key === "ArrowDown") {
        event.preventDefault();
        
        if (video.volume > 0.1) {
            video.volume -= 0.1;
        } else {
            video.volume = 0;
        }
        updateVolumeTextAndIcon();
    }
}


// Event Listeners
video.addEventListener("timeupdate", updateProgressBar);
video.addEventListener('timeupdate', () => {
    const progressPercentage = (video.currentTime / video.duration) * 100;
    progress.style.width = `${progressPercentage}%`;
});
progress.addEventListener("click", seek);
progress.addEventListener("touchstart", (event) => {
    touchStartX = event.touches[0].clientX;
});
progress.addEventListener("touchend", (event) => {
    touchEndX = event.changedTouches[0].clientX;
    const progressBarWidth = progress.offsetWidth;
    const seekTime = (touchEndX / progressBarWidth) * video.duration;
    video.currentTime = seekTime;
});
playPauseButton.addEventListener('click', togglePlayPause);
muteButton.addEventListener('click', toggleMute);
skipBackButton.addEventListener('click', skipBackward);
skipForwardButton.addEventListener('click', skipForward);
restartButton.addEventListener('click', () => {
    video.currentTime = 0;
});
document.addEventListener("keydown", handleVideoKeyPress);
customControls2.addEventListener("mousemove", showControls);
customControls2.addEventListener("keydown", showControls);
fullscreenButton.addEventListener("click", toggleFullscreen);
volumeUpArea.addEventListener("click", () => {
    if (video.volume < 1) {
        video.volume += 0.1;
    }
    updateVolumeTextAndIcon();
});
volumeDownArea.addEventListener("click", () => {
    if (video.volume > 0.1) {
        video.volume -= 0.1;
    } else {
        video.volume = 0;
    }
    updateVolumeTextAndIcon();
});

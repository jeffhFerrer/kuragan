<?php
// Inclui o cabeçalho do site
include_once('include/header.php');

// ações
$paginas = array(
    'home' => 'pg/home.php',
    'log' => 'pg/log_users.php',
    'reg' => 'pg/reg_users.php',
    'chat' => 'pg/chat.php',
    'msg' => 'include/mensagem.php',
    'erro' => 'pg/erro.php',
);

// Obtém o valor da ação da URL ou define como 'home' por padrão
$acao = isset($_GET['acao']) ? $_GET['acao'] : 'home';

// Verifica se a página está definida no array, caso contrário, define como 'erro'
if (!array_key_exists($acao, $paginas)) {
    $acao = 'erro';
}


// Define o caminho completo para o arquivo da página com base na ação
$caminhoPagina = $paginas[$acao];

// Inclui a página correspondente
include_once($caminhoPagina);

// Inclui o rodapé do site
include_once('include/footer.php');

const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 3000 });

// Estrutura para manter um registro dos clientes conectados
const clients = new Map();

wss.on('connection', ws => {
    // Quando um novo cliente se conecta
    ws.on('message', message => {
        const data = JSON.parse(message);
        if (data.type === 'register') {
            // Registra o cliente com o ID fornecido
            clients.set(data.id, ws);
            console.log(`Cliente registrado com ID: ${data.id}`);
        } else if (data.type === 'offer' || data.type === 'answer' || data.type === 'candidate') {
            // Encaminha a mensagem de sinalização para o destinatário
            const targetClient = clients.get(data.targetId);
            if (targetClient) {
                targetClient.send(JSON.stringify(data));
            } else {
                console.log(`Destinatário não encontrado: ${data.targetId}`);
            }
        }
    });

    ws.on('close', () => {
        // Remove o cliente da lista de clientes conectados
        clients.forEach((client, id) => {
            if (client === ws) {
                clients.delete(id);
            }
        });
        console.log('Conexão fechada');
    });
});

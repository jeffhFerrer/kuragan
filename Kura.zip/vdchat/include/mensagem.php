<link rel="stylesheet" href="style/msg_style.css">
<div class="d-flex justify-content-center align-items-center" id="mensagem-container">
    <div class="loader" id="loader"></div>
    <div class="card text-center" id="mensagem-card">
        <div class="card-body" id="card-msg">
            <img src="img/msg.png" alt="" style="width: calc( 100% - 50px);">
            <h5 class="card-title" id="mensagem-titulo">Título da Mensagem</h5>
            <p class="card-text" id="mensagem-texto">Texto da mensagem.</p>
            <a id="vlt" href="#" class="btn btn-outline-warning" onclick="voltar()">Voltar</a>
        </div>
    </div>
</div>

<script>
    function voltar() {
        window.history.back();
    }

    function configurarMensagem(titulo, texto, redirecionamento, tempoEspera = 2000, tempoRedirecionamento = 3000, mostrarBotaoVoltar = true) {
        $('#mensagem-titulo').text(titulo);
        $('#mensagem-texto').text(texto);
        $('#vlt').toggle(mostrarBotaoVoltar);

        setTimeout(function() {
            $('#loader').fadeOut();
            $('#mensagem-card').fadeIn();

            if (redirecionamento) {
                setTimeout(function() {
                    $('#loader, #mensagem-card').css('display', '');
                    setTimeout(function() {
                        window.location.href = redirecionamento;
                    }, tempoRedirecionamento);
                }, 3000);
            }
        }, tempoEspera);
    }
</script>

<?php
if (isset($_GET['status'])) {
    $status = $_GET['status'];
    $titulo = '';
    $texto = '';
    $redirecionamento = null;
    $tempoEspera = 2000;
    $tempoRedirecionamento = 2000;
    $mostrarBotaoVoltar = true;

    switch ($status) {
        case 'sucesso':
            $titulo = 'Sucesso!';
            $texto = 'Operação realizada com sucesso.';
            $redirecionamento = 'index.php?acao=chat';
            break;

        case 'log_sucesso':
            $titulo = 'Sucesso!';
            $texto = 'Operação realizada com sucesso.';
            $redirecionamento = 'index.php?acao=chat';
            $mostrarBotaoVoltar = false;
            break;

        case 'reg_sucesso':
            $titulo = 'Bem Vindo!';
            $texto = 'Registro realizado com sucesso.';
            $redirecionamento = 'index.php?acao=log';
            $mostrarBotaoVoltar = false;
            break;

        case 'falha':
            $titulo = 'Falha';
            $texto = 'Houve um erro durante a operação.';
            break;

        case 'email_duplicado':
            $titulo = 'Falha';
            $texto = 'Houve um erro durante a operação, (e-mail já registrado).';
            break;

        case 'off':
            $titulo = 'Sucesso!';
            $texto = 'Logout realizado com sucesso.';
            $redirecionamento = 'index.php';
            $mostrarBotaoVoltar = false;
            session_unset();
            session_destroy();
            break;

        default:
            $titulo = 'Erro';
            $texto = 'Status não reconhecido.';
            break;
    }

    echo "<script>configurarMensagem('$titulo', '$texto', " . json_encode($redirecionamento) . ", $tempoEspera, $tempoRedirecionamento, " . json_encode($mostrarBotaoVoltar) . ");</script>";
}
?>
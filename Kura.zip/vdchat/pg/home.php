<style>
    .line-center {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }

    .line-center-cl {
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }

    .cd-btn {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-evenly;
    }

    #img-logo {
        width: calc(100% - 50px);
    }


    @media (max-width: 768px) {
        .line-center-cl {
            height: 50vh;
        }
    }

    .line-center a {
        width: 100px;
        font-weight: 900;
        border: 2px solid;
    }

    .line-center p {
        color: #fff;
        font-weight: 700;
        text-align: justify;
    }
</style>
<div class="container">
    <div class="row">
        <!-- Coluna para texto e imagem -->
        <div class="col-md-6 line-center-cl">
            <img id="img-logo" src="img/vdchat.png" alt="Descrição da imagem">
        </div>

        <!-- Coluna para botões -->
        <div class="col-md-6 line-center">
            <p>
                Descubra <strong>VD CHAT</strong>, a nova plataforma revolucionária de vídeo chamadas,
                onde conectar-se com o mundo é apenas um clique distante! Inspirado na
                espontaneidade do Omegle, mas com segurança e privacidade aprimoradas,
                <strong>VD CHAT</strong> oferece uma maneira única e emocionante de fazer novos amigos,
                aprender sobre culturas diferentes, e ter conversas memoráveis. Cadastre-se
                agora e comece a explorar uma comunidade global na palma da sua mão!
            </p>
            <div class="cd-btn">
                <a href="index.php?acao=reg" class="btn btn-outline-light">Registrar</a>
                <a href="index.php?acao=log" class="btn btn-outline-warning">Login</a>
            </div>
        </div>
    </div>
</div>
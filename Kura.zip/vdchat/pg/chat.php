<link rel="stylesheet" href="style/style.css">
<?php
include_once('conect/conexao.php');

// Supondo que o ID do usuário logado está armazenado em $_SESSION['user_id']
$userId = $_SESSION['user_id'];

// Preparar a consulta
$query = "SELECT status FROM users WHERE id = :userId";
$stmt = $conexao->prepare($query);
$stmt->bindParam(':userId', $userId, PDO::PARAM_INT);

// Executar a consulta
$stmt->execute();

// Obter o resultado
$user = $stmt->fetch(PDO::FETCH_ASSOC);


// Verificar o status e definir o texto do botão
$buttonText = '<i class="fas fa-comment-dots"></i>';
if ($user && $user['status'] == 1) {
    $buttonText = '<i class="fas fa-comment-slash"></i>';
}else{
    $buttonText =  '<i class="fas fa-comment-dots"></i>';
}
?>
<div id="user-data" data-user-id="<?php echo htmlspecialchars($userId, ENT_QUOTES, 'UTF-8'); ?>" style="display: none;"></div>
<div class="container mt-4">
    <div class="text-center mt-3" style="margin-top: 0 !important; margin-bottom: 20px;">
        <span id="active-users-count">Usuários Ativos: 0</span>
    </div>

    <div class="row" id="video-chat-container">
        <div class="col-md-6" id="sub-video-container">
            <video id="local-video" autoplay muted></video>
        </div>
        <div class="col-md-6" id="sub-video-container">
            <video id="remote-video" autoplay></video>
            <canvas id="noise-canvas" style=" display: none;"></canvas>
        </div>
    </div>
    <div class="text-center mt-3">
        <button id="toggle-call" class="btn btn-primary" onclick="toggleCall()"><?php echo $buttonText; ?></button>
        <button id="skip-call" class="btn btn-secondary"><i class="fas fa-forward"></i></button>
        <button id="logout" class="btn btn-danger" onclick="logout()"><i class="fas fa-sign-out-alt"></i></button>
    </div>

</div>

<script src="style/script.js"></script>
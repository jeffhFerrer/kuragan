<style>
    body {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
    }

    .form-container {
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0px 0px 10px 0px #00000026;
    }
</style>

<div class="container" style="padding: 50px;position: absolute;left: 50%;top: 50%;transform: translate(-50%, -50%);">
    <div class="row justify-content-md-center">
        <div class="col-md-4 form-container">
            <h2 class="text-center">Registro de Usuário</h2>
            <form action="forms/register.php" method="POST">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Senha:</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" name="reg" class="btn btn-primary">Registrar</button>
            </form>
        </div>
    </div>
</div>
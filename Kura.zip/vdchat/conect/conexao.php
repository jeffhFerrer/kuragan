<?php
$host = 'localhost';
$dbname = 'id21191845_kuragan';
$username = 'id21191845_root';
$password = 'Kuragan@12102005';

try {
    $conexao = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Configurar o modo de erro do PDO para exceção
    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erro na conexão: " . $e->getMessage();
}

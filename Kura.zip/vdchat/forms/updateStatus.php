<?php
session_start();
include('../conect/conexao.php');

if (isset($_POST['status']) && isset($_SESSION['user_id'])) {
    $status = $_POST['status'];
    $userId = $_SESSION['user_id'];

    try {
        $sql = "UPDATE users SET status = :status WHERE id = :id";
        $stmt = $conexao->prepare($sql);

        $stmt->bindParam(':status', $status, PDO::PARAM_INT);
        $stmt->bindParam(':id', $userId, PDO::PARAM_INT);

        $stmt->execute();
    } catch (PDOException $e) {
        // Tratar erro
        echo "Erro: " . $e->getMessage();
    }
}

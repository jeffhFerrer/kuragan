<?php
session_start();
include('../conect/conexao.php');

if (isset($_POST['log'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        $sql = "SELECT id, password FROM users WHERE email = :email";
        $stmt = $conexao->prepare($sql);
        
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (password_verify($password, $row['password'])) {
                $_SESSION['user_id'] = $row['id'];
                header("Location: ../index.php?acao=msg&status=log_sucesso");
            } else {
                header("Location: ../index.php?acao=msg&status=falha");
            }
        } else {
            header("Location: ../index.php?acao=msg&status=falha");
        }
    } catch(PDOException $e) {
        header("Location: ../index.php?acao=msg&status=falha");
    }
} else {
    // Redireciona para a página de login se o método não for POST
    header("Location: ../index.html?acao='log'"); // Substitua login.html pelo caminho da sua página de login
}
?>
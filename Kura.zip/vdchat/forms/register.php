<?php
include('../conect/conexao.php');

if (isset($_POST['reg'])) {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    try {
        // Verificar se o e-mail já existe
        $sql = "SELECT COUNT(*) FROM users WHERE email = :email";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->fetchColumn() > 0) {
            // E-mail já existe
            header("Location: ../index.php?acao=msg&status=email_duplicado");
        } else {
            // E-mail não existe, prosseguir com o registro
            $sql = "INSERT INTO users (email, password) VALUES (:email, :password)";
            $stmt = $conexao->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $password);
            $stmt->execute();
            header("Location: ../index.php?acao=msg&status=reg_sucesso");
        }
    } catch(PDOException $e) {
        header("Location: ../index.php?acao=msg&status=falha");
    }
} else {
    // Redireciona para a página de registro se o método não for POST
    header("Location: ../index.html?acao='reg'");
}
?>

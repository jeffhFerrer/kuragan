<?php
include('../conect/conexao.php');

try {
    $sql = "SELECT COUNT(*) FROM users WHERE status = 1";
    $stmt = $conexao->prepare($sql);
    $stmt->execute();

    $count = $stmt->fetchColumn();
    echo json_encode(['count' => $count]);
} catch (PDOException $e) {
    echo json_encode(['count' => 0, 'error' => $e->getMessage()]);
}

let localStream = null;
let peerConnection = null;
const configuration = { 'iceServers': [{ 'urls': 'stun:stun.example.org' }] };

// Capturar mídia local
navigator.mediaDevices.getUserMedia({ video: true, audio: true })
    .then(stream => {
        document.getElementById('local-video').srcObject = stream;
        localStream = stream;
    })
    .catch(error => console.error('Erro ao obter mídia local:', error));

// Inicializar a conexão peer-to-peer
function startPeerConnection() {
    peerConnection = new RTCPeerConnection(configuration);
    localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));

    // Tratar eventos de candidatos ICE
    peerConnection.onicecandidate = event => {
        if (event.candidate) {
            // Enviar candidato ICE ao servidor de sinalização
        }
    };

    // Configurar stream remoto
    peerConnection.ontrack = event => {
        document.getElementById('remote-video').srcObject = event.streams[0];
    };
}

// Funções para criar oferta, criar resposta, e definir descrições locais e remotas
// ...

function toggleCall() {
    const callButton = document.getElementById('toggle-call');
    let status;
    if (callButton.textContent === 'Iniciar Conversa') {
        callButton.textContent = 'Finalizar Conversa';
        status = 1; // Usuário está em uma chamada
        startPeerConnection();
    } else {
        callButton.textContent = 'Iniciar Conversa';
        status = 0; // Usuário não está em uma chamada
    }

    // Enviar requisição para atualizar o status do usuário
    fetch('forms/updateStatus.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'status=' + status
    });
}

function logout() {
    sts = 0;
    fetch('forms/updateStatus.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'status=' + sts
    });

    window.location.href = 'index.php?acao=msg&status=off'; // Redireciona para o script de logout
}

//ATUALIZAÇÃO DE USUÁRIOS ATIVOS
function updateActiveUsersCount() {
    fetch('forms/getActiveUsersCount.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('active-users-count').textContent = 'Usuários Ativos: ' + data.count;
        })
        .catch(error => console.error('Erro ao obter número de usuários ativos:', error));
}

// Atualizar a contagem de usuários ativos a cada segundo
setInterval(updateActiveUsersCount, 1000);

// Atualizar imediatamente ao carregar a página
updateActiveUsersCount();
let localStream = null;
let peerConnection = null;
const configuration = { 'iceServers': [{ 'urls': 'stun:stun.l.google.com:19302' }] };
const meuId = document.getElementById('user-data').getAttribute('data-user-id');

// Estabelece uma conexão WebSocket
const socket = new WebSocket('wss://kuragan.000webhostapp.com:3000');

socket.onopen = () => {
    console.log('Conexão WebSocket aberta');
    socket.send(JSON.stringify({ type: 'register', id: meuId }));
};

socket.onmessage = message => {
    try {
        const data = JSON.parse(message.data);
        if (data.type === 'offer') {
            receberOferta(data);
        } else if (data.type === 'answer') {
            peerConnection.setRemoteDescription(new RTCSessionDescription(data));
        } else if (data.type === 'candidate') {
            peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
        }
    } catch (e) {
        console.log('Mensagem recebida:', message.data);
    }
};

socket.onerror = error => {
    console.error('Erro na conexão WebSocket:', error);
};

socket.onclose = () => {
    console.log('Conexão WebSocket fechada');
};

// Função para receber uma oferta WebRTC
function receberOferta(data) {
    peerConnection = new RTCPeerConnection(configuration);
    localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));
    configurarPeerConnection();

    peerConnection.setRemoteDescription(new RTCSessionDescription(data));
    peerConnection.createAnswer().then(answer => {
        peerConnection.setLocalDescription(answer);
        socket.send(JSON.stringify({ type: 'answer', sdp: answer.sdp, targetId: data.id }));
    });
}

// Função para iniciar uma chamada
function iniciarChamada(idDestinatario) {
    peerConnection = new RTCPeerConnection(configuration);
    localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));
    configurarPeerConnection();

    peerConnection.createOffer().then(offer => {
        peerConnection.setLocalDescription(offer);
        socket.send(JSON.stringify({ type: 'offer', sdp: offer.sdp, targetId: idDestinatario }));
    }).catch(error => console.error('Erro ao criar oferta:', error));
}

// Configura eventos do peerConnection
function configurarPeerConnection() {
    peerConnection.onicecandidate = event => {
        if (event.candidate) {
            socket.send(JSON.stringify({ type: 'candidate', candidate: event.candidate, targetId: 'destinatarioId' })); // Substitua 'destinatarioId' conforme necessário
        }
    };

    peerConnection.ontrack = event => {
        document.getElementById('remote-video').srcObject = event.streams[0];
    };
}

// Função para finalizar chamada
function finalizarChamada() {
    if (peerConnection) {
        peerConnection.close();
        peerConnection = null;
    }
    // Outras ações para finalizar a chamada
}

// Capturar mídia local
navigator.mediaDevices.getUserMedia({ video: true, audio: true })
    .then(stream => {
        document.getElementById('local-video').srcObject = stream;
        localStream = stream;
    })
    .catch(error => console.error('Erro ao obter mídia local:', error));



function toggleCall() {
    const callButton = document.getElementById('toggle-call');
    let status;

    // Verificar se o ícone atual é o de iniciar chamada (comment-dots)
    if (callButton.innerHTML.includes('fa-comment-dots')) {
        callButton.innerHTML = '<i class="fas fa-comment-slash"></i>';
        status = 1; // Usuário está em uma chamada
        iniciarChamada();
        // Aqui, você pode adicionar a lógica para criar e enviar uma oferta
    } else {
        callButton.innerHTML = '<i class="fas fa-comment-dots"></i>';
        status = 0; // Usuário não está em uma chamada
        // Finalizar chamada e fechar conexões
        finalizarChamada();
    }

    // Enviar requisição para atualizar o status do usuário
    fetch('forms/updateStatus.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'status=' + status
    });
}


function logout() {
    sts = 0;
    fetch('forms/updateStatus.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'status=' + sts
    });

    window.location.href = 'index.php?acao=msg&status=off'; // Redireciona para o script de logout
}

//ATUALIZAÇÃO DE USUÁRIOS ATIVOS
function updateActiveUsersCount() {
    fetch('forms/getActiveUsersCount.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('active-users-count').textContent = 'Usuários Ativos: ' + data.count;
        })
        .catch(error => console.error('Erro ao obter número de usuários ativos:', error));
}

// Atualizar a contagem de usuários ativos a cada 30 segundos
setInterval(updateActiveUsersCount, 1000);

// Atualizar imediatamente ao carregar a página
updateActiveUsersCount();


document.addEventListener("DOMContentLoaded", function () {
    var video = document.getElementById("remote-video");
    var canvas = document.getElementById("noise-canvas");
    var ctx = canvas.getContext('2d');

    function drawNoise() {
        var imageData = ctx.createImageData(canvas.width, canvas.height);
        var data = imageData.data;

        for (var i = 0; i < data.length; i += 4) {
            var val = Math.floor(Math.random() * 255);
            data[i] = data[i + 1] = data[i + 2] = val;
            data[i + 3] = 255;
        }

        ctx.putImageData(imageData, 0, 0);
        requestAnimationFrame(drawNoise);
    }

    function checkVideoStream() {
        if (video.readyState < 2) {
            video.style.display = "none";
            canvas.style.display = "block";
            drawNoise();
        } else {
            video.style.display = "block";
            canvas.style.display = "none";
        }
    }

    setInterval(checkVideoStream, 1000);
    video.addEventListener('playing', checkVideoStream);
    video.addEventListener('waiting', checkVideoStream);
    video.addEventListener('ended', checkVideoStream);
    video.addEventListener('emptied', checkVideoStream);
});

$(document).ready(function() {
    // Simular carregamento
    setTimeout(function() {
        $('.loader').fadeOut();
        $('#mensagem-card').fadeIn();
    }, 2000); // Ajuste o tempo conforme necessário
});

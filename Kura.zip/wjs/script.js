$(document).ready(function () {
    $("#formMensagem").submit(function (event) {
        event.preventDefault();

        var nome = encodeURIComponent($("#nome").val());
        var mensagem = encodeURIComponent($("#mensagem").val());

        $.ajax({
            type: "POST",
            url: "salvar_mensagem.php",
            data: { nome: nome, mensagem: mensagem },
            success: function (response) {
                $("#link").html(response);
                $("#nome, #mensagem").val(""); // Limpa os campos após o envio
            },
            error: function (error) {
                console.error("Erro ao enviar mensagem: " + error.responseText);
            }
        });
    });
});

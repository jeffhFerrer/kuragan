<?php
$servername = "localhost";
$username = "id21191845_root";
$password = "Kuragan@12102005";
$dbname = "id21191845_kuragan";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

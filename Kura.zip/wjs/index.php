<?php include('conexao/conect.php'); ?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-adsense-account" content="ca-pub-8461031365208671">
    <title>WJS</title>

    <!-- Adicione os links para Bootstrap e jQuery -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">


    <!-- Adicione estilos natalinos personalizados -->
    <style>
        body {
            background-color: #f0f0f0;
        }

        .container {
            margin-top: 50px;
        }
        
        a[href^="https://www.000webhost.com/"] {
            display: none;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        button {
            background-color: #cc0000;
            color: #fff;
        }

        #btnShare {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #007bff;
            /* Azul intenso */
            border: 2px solid #007bff;
            /* Borda azul intenso */
            color: #fff;
            /* Texto branco */
            border-radius: 50%;
            /* Torna o botão redondo */
            padding: 10px;
            /* Adiciona algum preenchimento para melhorar a aparência */
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
            /* Adiciona transição de cores */
        }

        #btnShare:hover {
            background-color: transparent;
            /* Background transparente no hover */
            color: #007bff;
            /* Texto azul intenso no hover */
        }

        #btnShare:active {
            border-color: #007bff;
            /* Borda azul intenso quando clicado */
            color: #007bff;
            /* Texto azul intenso quando clicado */
        }

        img[src="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"] {
            display: none;
        }
    </style>
</head>

<body>

    <?php
    // Inicialização padrão
    $mensagem_enviada = false;
    $erro_mensagem = '';
    if (isset($_POST["enviar"])) {
        if (!empty($_POST["nome"]) && !empty($_POST["mensagem"]) && !empty($_POST["data_comemorativa"])) {
            // Processar o formulário e enviar a mensagem
            $nome = $_POST["nome"];
            $mensagem = $_POST["mensagem"];
            $data_comemorativa = $_POST["data_comemorativa"];

            // Obter a data do dispositivo do usuário
            date_default_timezone_set('America/Sao_Paulo'); // Defina o fuso horário adequado
            $data_envio = date("Y-m-d H:i:s");

            // Preparar a declaração SQL para inserir dados
            $stmt = $conn->prepare("INSERT INTO mensagens (nome, mensagem, data_comemorativa, data_envio) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nome, $mensagem, $data_comemorativa, $data_envio);

            // Executar a declaração SQL
            if ($stmt->execute()) {
                $mensagem_enviada = true;
                // Obter o ID da mensagem recém-inserida
                $id_mensagem = $stmt->insert_id;

                // Converta o ID para base64
                $id_base64 = base64_encode($id_mensagem);
            } else {
                $erro_mensagem = "Erro ao enviar a mensagem. Tente novamente.";
            }

            // Fechar a declaração
            $stmt->close();
        } else {
            $erro_mensagem = "Por favor, preencha todos os campos do formulário.";
        }
    }

    // Fechar a conexão ao final do script
    $conn->close();
    ?>

    <div class="container">
        <form method="POST" action="">
            <h2 class="text-center mb-4">Inserir Mensagem</h2>

            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="data_comemorativa">Tipo de Mensagem:</label>
                <select name="data_comemorativa" class="form-control" required>
                    <option value="">Selecione o tipo de mensagem</option>
                    <option value="birthday">Aniversário</option>
                    <option value="natal">Natal</option>
                    <option value="ano_novo">Ano Novo</option>
                    <option value="especial">Amizade</option>
                    <option value="valentines_day">Dia dos Namorados</option>
                <!--
                    <option value="mothers_day">Dia das Mães</option>
                    <option value="fathers_day">Dia dos Pais</option>
                    <option value="halloween">Halloween</option>
                    <option value="thanksgiving">Ação de Graças</option>
                -->
                </select>
            </div>

            <div class="form-group">
                <label for="mensagem">Mensagem:</label>
                <textarea name="mensagem" class="form-control" required></textarea>
            </div>

            <button type="submit" name="enviar" class="btn btn-primary btn-block">Enviar Mensagem</button>

            <?php if ($mensagem_enviada) : ?>
                <div class="alert alert-success text-center mt-3">Mensagem enviada com sucesso! <a href='get.php?id=<?php echo $id_base64; ?>' target='_blank'>Exibir</a></div>
                <span id="btnShare">
                    <i class="fas fa-share"></i>
                </span>

                <script>
                    document.getElementById('btnShare').addEventListener('click', () => {
                        if (navigator.share) {
                            navigator.share({
                                    title: '<?php echo $nome; ?> te Enviou uma Mensagem Surpresa',
                                    text: 'Clique no link para receber a mensagem surpresa!',
                                    url: 'https://kuragan.000webhostapp.com/wjs/get.php?id=<?php echo $id_base64; ?>'
                                })
                                .then(() => console.log('Conteúdo compartilhado com sucesso!'))
                                .catch((error) => console.error('Erro ao compartilhar:', error));
                        } else {
                            alert('A API Web Share não é suportada neste navegador.');
                        }
                    });
                </script>
            <?php elseif ($erro_mensagem) : ?>
                <div class="alert alert-danger text-center mt-3"><?php echo $erro_mensagem; ?></div>
            <?php endif; ?>
        </form>

    </div>

</body>

</html>
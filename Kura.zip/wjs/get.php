<?php
include("conexao/conect.php");
// Verificar se foi passado um ID de mensagem válido
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id_mensagem = base64_decode($_GET['id']);

    // Buscar a mensagem no banco de dados
    $sql = "SELECT * FROM mensagens WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_mensagem);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $mensagem = $result->fetch_assoc();
    } else {
        // Se não encontrar a mensagem, redirecionar para a página de erro ou exibir uma mensagem adequada
        header("Location: erro.php");
        exit();
    }

    $stmt->close();
} else {
    // Se não houver um ID de mensagem válido, redirecionar para a página de erro
    header("Location: erro.php");
    exit();
}

// Fechar a conexão ao final do script
$conn->close();
?>

<?php
$musica_fundo = "efeitos/natal.mp3"; // Padrão, pode ser ajustado conforme necessário
$imagem_esquerda = "img/natal_esquerda.png"; // Padrão, pode ser ajustado conforme necessário
$imagem_direita = "img/natal_direita.png"; // Padrão, pode ser ajustado conforme necessário
$img_flc = "natal_flc.png"; // Padrão, pode ser ajustado conforme necessário

switch ($mensagem['data_comemorativa']) {
    case 'birthday':
        $musica_fundo = "efeitos/aniversario.mp3";
        $imagem_esquerda = "img/aniversario_esquerda.png";
        $imagem_direita = "img/aniversario_direita.png";
        $img_flc = "aniversario_flc.png";
        $cor_fundo = "img/aniversario.png";
        $cortinaD = "linear-gradient(to right, #8e44ad, #3498db)";
        $cortinaE = "linear-gradient(to left, #8e44ad, #3498db)";

        break;
    case 'natal':
        $musica_fundo = "efeitos/natal.mp3";
        $imagem_esquerda = "img/natal_esquerda.png";
        $imagem_direita = "img/natal_direita.png";
        $img_flc = "natal_flc.png";
        $cor_fundo = "img/natal.png";
        $cortinaD = "linear-gradient(to right, #c70039, #ff5733)";
        $cortinaE = "linear-gradient(to left, #c70039, #ff5733)";
        break;
    case 'ano_novo':
        $musica_fundo = "efeitos/ano_novo.mp3";
        $imagem_esquerda = "img/ano_novo_esquerda.png";
        $imagem_direita = "img/ano_novo_direita.png";
        $img_flc = "ano_novo_flc.png";
        $cor_fundo = "img/ano_novo.png";
        $cortinaD = "linear-gradient(to right, #0f4c75, #00a8cc)";
        $cortinaE = "linear-gradient(to left, #0f4c75, #00a8cc)";
        break;
    case 'especial':
        $musica_fundo = "efeitos/especial.mp3";
        $imagem_esquerda = "img/especial_esquerda.png";
        $imagem_direita = "img/especial_direita.png";
        $img_flc = "especial_flc.png";
        $cor_fundo = "img/especial.png";
        $cortinaD = "linear-gradient(to right, #4CAF50, #8BC34A)";
        $cortinaE = "linear-gradient(to left, #4CAF50, #8BC34A)";
        break;
    case 'valentines_day':
        $musica_fundo = "efeitos/valentines_day.mp3";
        $imagem_esquerda = "img/valentines_day_esquerda.png";
        $imagem_direita = "img/valentines_day_direita.png";
        $img_flc = "valentines_day_flc.png";
        $cor_fundo = "img/valentines_day.png";
        $cortinaD = "linear-gradient(to right, #ff7e5f, #feb47b)";
        $cortinaE = "linear-gradient(to left, #ff7e5f, #feb47b)";
        break;
        /* 
    case 'mothers_day':
        $musica_fundo = "efeitos/dia-das-maes.mp3";
        $imagem_esquerda = "img/mothers_day_esquerda.png";
        $imagem_direita = "img/mothers_day_direita.png";
        $img_flc = "mothers_day_flc.png";
        break;
    case 'fathers_day':
        $musica_fundo = "efeitos/dia-dos-pais.mp3";
        $imagem_esquerda = "img/fathers_day_esquerda.png";
        $imagem_direita = "img/fathers_day_direita.png";
        $img_flc = "fathers_day_flc.png";
        break;
    case 'halloween':
        $musica_fundo = "efeitos/halloween.mp3";
        $imagem_esquerda = "img/halloween_esquerda.png";
        $imagem_direita = "img/halloween_direita.png";
        $img_flc = "halloween_flc.png";
        break;
    case 'thanksgiving':
        $musica_fundo = "efeitos/acao-de-gracas.mp3";
        $imagem_esquerda = "img/thanksgiving_esquerda.png";
        $imagem_direita = "img/thanksgiving_direita.png";
        $img_flc = "thanksgiving_flc.png";
        break; */
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-adsense-account" content="ca-pub-8461031365208671">
    <meta property="og:title" content="<?php echo htmlspecialchars($mensagem['nome']); ?> te Enviou uma Mensagem Surpresa">
    <meta property="og:description" content="Clique no link para receber a mensagem surpresa!">
    <meta property="og:url" content="https://kuragan.000webhostapp.com/wjs/<?php echo $_GET['id']; ?>">
    <title>WJS</title>

    <!-- Adicione os links para Bootstrap e jQuery -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- Adicione um link para o arquivo de áudio natalino -->
    <audio id="audio" preload="auto">
        <source src="<?php echo $musica_fundo; ?>" type="audio/mpeg">
        Seu navegador não suporta o elemento de áudio.
    </audio>

    <script>
        var cortinasAbertas = false;

        function toggleCortinas() {
            if (cortinasAbertas) {
                $(".cortina-esquerda, .cortina-direita").animate({
                    width: "50%",
                });
                cortinasAbertas = false;
                $("#botao-cortinas").text("Abrir");
            } else {
                $(".cortina-esquerda, .cortina-direita").animate({
                    width: "0%",
                });
                cortinasAbertas = true;
                $("#botao-cortinas").text("Fechar");
            }
            $(document).ready(function() {
                // Reproduzir o áudio ao carregar a página
                var audio = document.getElementById("audio");
            
                // Adicionar um ouvinte de evento para reiniciar quando a música terminar
                audio.addEventListener('ended', function() {
                    audio.currentTime = 0; // Define o tempo atual para o início
                    audio.play(); // Inicia a reprodução novamente
                });
            
                // Reduz o volume pela metade
                audio.volume = 0.20;
            
                audio.play(); // Inicia a reprodução inicial
            });

        }

        $(document).ready(function() {
            $("#botao-cortinas").click(function() {
                toggleCortinas();
            });
        });
    </script>

    <script>
        // Função para criar flocos de neve
        function criarFlocosNeve() {
            for (let i = 0; i < 20; i++) {
                const flocoNeve = $(`<div class="floco-neve"></div>`);
                const posicaoInicial = Math.random() * window.innerWidth;
                const atrasoInicial = Math.random() * 0;

                flocoNeve.css({
                    'left': posicaoInicial,
                    'top': -50, // Posição inicial acima do topo da página
                    'animation-delay': `-${atrasoInicial}s`
                });

                // Adicionar floco de neve à página
                $('.container').append(flocoNeve);

                // Iniciar animação de queda e rotação
                animarQuedaERotacao(flocoNeve);
            }
        }

        // Função para animar a queda e a rotação de um floco de neve
        function animarQuedaERotacao(flocoNeve) {
            const duracaoQueda = Math.random() * 10 + 10; // Duração entre 10 e 20 segundos
            const duracaoRotacao = Math.random() * 2 + 2; // Duração entre 2 e 4 segundos

            const rotationInterval = 50; // Intervalo de tempo para a rotação (em milissegundos)
            let rotationDegree = 0;

            // Iniciar intervalo para a rotação contínua
            const rotationIntervalId = setInterval(function() {
                rotationDegree += 1;
                flocoNeve.css({
                    transform: 'rotate(' + rotationDegree + 'deg)'
                });
            }, rotationInterval);

            flocoNeve.animate({
                    top: '100vh'
                }, // Animação de queda
                {
                    duration: duracaoQueda * 1000,
                    easing: 'linear',
                    complete: function() {
                        // Reiniciar a posição acima do topo após a queda
                        $(this).css({
                            top: -50
                        });
                        // Parar o intervalo de rotação
                        clearInterval(rotationIntervalId);
                        // Chamar recursivamente para criar um loop contínuo
                        animarQuedaERotacao($(this));
                    }
                }
            );
        }

        // Chamar a função ao carregar a página
        $(document).ready(function() {
            criarFlocosNeve();
        });
    </script>

    <style>
        body {
            background-image: url(' <?php echo $cor_fundo; ?>');
            background-size: cover;
            /* ou 'contain' se preferir */
            background-repeat: no-repeat;
            background-position: center center;
            background-attachment: fixed;
            margin: 0;
            margin: 0;
            overflow: hidden;
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        a[href^="https://www.000webhost.com/"] {
            display: none;
        }

        .container {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .cortina {
            position: absolute;
            top: 0;
            bottom: 0;
            z-index: 3;
            transition: width 5s;
        }

        .cortina-esquerda {
            background: <?php echo $cortinaE; ?>;
            left: 0;
            width: 50%;
            display: flex;
            align-items: center;
            justify-content: right;
        }

        .cortina-direita {
            background: <?php echo $cortinaD; ?>;
            right: 0;
            width: 50%;
            display: flex;
            align-items: center;
            justify-content: left;
        }

        .cortina img {
            width: 200px;
            height: 200px;
        }

        #carta-aberta {
            display: none;
            z-index: 1;
            position: absolute;
            top: 0;
            bottom: 0;
            width: 100%;
            max-width: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }

        h5,
        p {
            text-align: center;
            color: #fff;
            text-align: justify;

            text-shadow: 2px 2px 4px #000;
        }

        p {
            font-weight: 900;
        }

        #botao-cortinas {
            position: absolute;
            left: 50%;
            bottom: 20px;
            transform: translateX(-50%);
            padding: 10px 20px;
            font-size: 18px;
            background: #fff;
            color: red;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            z-index: 1000;
            outline: none;
            font-weight: 900;
            text-transform: uppercase;
        }

        #botao-criar {
            position: absolute;
            top: 20px;
            padding: 7px;
            border-radius: 20px;
            font-size: 18px;
            background: #fff;
            color: red;
            border: none;
            cursor: pointer;
            z-index: 2;
            outline: none;
            font-weight: 900;
            text-transform: uppercase;
            text-decoration: none;
        }

        #botao-cortinas:hover,
        #botao-criar:hover {
            background: #ffffff98;
            color: red;
        }

        /* Estilos para os flocos de neve */
        .floco-neve {
            position: absolute;
            width: 50px;
            height: 50px;
            background-image: url('img/<?php echo $img_flc ?>');
            background-size: cover;
            background-repeat: no-repeat;
        }


        @media (max-width: 768px) {
            body {
                position: fixed;
            }

            #carta-aberta {
                max-width: calc(100% - 50px);
                padding: 0 20px 0 20px;
            }
        }
        img[src="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"] {
            display: none;
        }
    </style>

    </style>
</head>

<body>

    <div class="container">
        <!-- Cortinas -->
        <div class="cortina cortina-esquerda">
            <img src="<?php echo $imagem_esquerda; ?>" alt="">
        </div>
        <div class="cortina cortina-direita">
            <img src="<?php echo $imagem_direita; ?>" alt="">
        </div>

        <a href="./" id="botao-criar"><i class="fas fa-pencil-alt"></i> Crie o seu</a>

        <!-- Carta aberta -->
        <div id="carta-aberta">

            <h5><?php echo nl2br(htmlspecialchars($mensagem['mensagem'])); ?></h5>
            <p>Enviado por <?php echo htmlspecialchars($mensagem['nome']); ?></p>
        </div>

        <!-- Botão para abrir as cortinas -->
        <button id="botao-cortinas">Abrir</button>
    </div>

</body>

</html>
<?php
include_once('../conect/conexao.php');
session_start();
date_default_timezone_set('America/Fortaleza'); // Substitua pelo fuso horário correto

// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera os dados do formulário
    $user_id = $_SESSION["user_id"];
    $message = $_POST["message"]; // Mensagem enviada
    $currentTime = date("Y-m-d H:i:s"); // Data e hora de envio

    // Insere os dados na tabela tb_chat
    $sql = "INSERT INTO tb_chat (user_id, message, send_time) VALUES ('$user_id', '$message', '$currentTime')";

    if ($conn->query($sql) === TRUE) {
        echo "Mensagem enviada com sucesso!";
    } else {
        echo "Erro ao enviar mensagem ";
    }
}
?>
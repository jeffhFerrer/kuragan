<?php
session_start();
include_once('../conect/conexao.php');
// Consulta para obter as mensagens da tabela tb_chat, juntamente com as informações do usuário
$sql = "SELECT c.*, u.username, u.foto FROM tb_chat AS c
        JOIN tb_user AS u ON c.user_id = u.user_id
        ORDER BY c.send_time ASC";
$result = $conn->query($sql);
?>
<!-- Seu código HTML para a exibição das mensagens aqui -->
<?php
// Exibe as mensagens da consulta
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="message other-message">';
        echo '<div class="message-details">';
        echo '<img src="assets/user/' . $row["foto"] . '" alt="Foto do Usuário">';
        echo '<div class="message-info">';
        echo '<span class="user-name">' . $row["username"] . '</span></br>';
        echo '<span class="message-time">' . date('d/m/Y H:i:s', strtotime($row['send_time'])) . '</span>';
        echo '</div>';
        echo '</div>';
        echo '<div class="message-content">' . nl2br($row["message"]) . '</div>';
        echo '</div>';
    }
} else {
    echo "Nenhuma mensagem encontrada.";
}
?>
<link rel="stylesheet" href="chat/estilo/style.css">

<?php include_once('conect/conexao.php');
date_default_timezone_set('America/Fortaleza'); // Substitua pelo fuso horário correto

?>

<div class="chat-messages" id="chatContainer"></div>
<div id="messageResponse"></div>
<script>
    function getChat() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'chat/get_chat.php', true);

        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    document.getElementById('chatContainer').innerHTML = xhr.responseText;
                }
            }
        };

        xhr.send();
    }

    setInterval(getChat, 2000);
    getChat(); // Carregar notificações inicialmente
</script>

<?php if (isset($_SESSION['user_id'])): ?>
    <form class="input-container" id="sendMessageForm" method="post" action="">
        <!-- Campos ocultos para os dados do usuário -->

        <textarea name="message" id="messageInput" placeholder="Digite sua mensagem"></textarea>
        <button type="submit" id="sendButton" class="fas fa-paper-plane"></button>
    </form>
<?php else: ?>
    <!-- Mensagem para usuários não logados -->
    <p style="position:fixed; width:100%; text-align:center; bottom: 0;">Você precisa estar logado para participar. <a
            style="color: #ff0000; font-weight:700;" href="login.php">Login</a></p>
<?php endif; ?>
<script>
    // Obtém o elemento <textarea> pelo ID
    var textarea = document.getElementById('messageInput');

    // Define a altura máxima desejada em pixels
    var maxHeight = 100; // Altere este valor para o limite máximo desejado

    // Adiciona um ouvinte de evento para monitorar as mudanças de conteúdo
    textarea.addEventListener('input', function () {
        // Redefine a altura do <textarea> para 0 para que ele possa ser redimensionado conforme necessário
        this.style.height = '0';

        // Define a altura do <textarea> para a altura do conteúdo rolável, mas limita-a à altura máxima
        this.style.height = Math.min(this.scrollHeight, maxHeight) + 'px';
    });
    
    
    document.getElementById("sendMessageForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Impede o envio padrão do formulário
    var formData = new FormData(this); // Obtém os dados do formulário

    // Envia os dados via AJAX para processar_mensagem.php
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "chat/processa_mensagem.php", true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            document.getElementById("messageResponse").innerHTML = xhr.responseText;
            document.getElementById("messageInput").value = ""; // Limpa o campo de mensagem após o envio
            getChat(); // Atualiza o chat após enviar a mensagem
        } else {
            document.getElementById("messageResponse").innerHTML = "Erro ao enviar mensagem ajax";
        }
    };
    xhr.send(formData);
});

</script>
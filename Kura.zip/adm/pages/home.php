<?php
// Faz a conexão com o banco de dados
include('conect/conexao.php');

// Faz um SELECT na tabela tb_video para obter os dados dos vídeos que contenham o gênero selecionado
$sql = "SELECT * FROM tb_video ORDER BY video_id DESC";
$result = $conn->query($sql);
?>

<style>
    img{
        width: 100%;
        height: 100%;
    }

    .movie-card {
        margin-bottom: 0 !important;
    }
</style>
<link rel="stylesheet" href="../estilo/css/genero.css">
            <?php
            echo "<div class='row'>";

            // Variável para verificar se pelo menos um vídeo foi exibido
            $videoDisplayed = false;

            // Loop através de todos os vídeos
            mysqli_data_seek($result, 0); // Voltando ao início do resultado
            while ($movieRow = $result->fetch_assoc()) {
                $titulo = $movieRow['title'];
                $video_id = $movieRow['video_id'];
                $capa = $movieRow['capa'];

                echo '<div class="col-4 col-md-2" style="padding:5px;">';
                echo '<a href="../index.php?acao=video&video_id=' . $video_id . '" class="movie-card">';
                echo '<div style="background-image: url( ../' . $capa . ');" class="movie-image"></div>';
                echo '<img src="../assets/64e4213950bad.jpeg" alt="">';
                echo '<p>' . $titulo . '</p>';
                echo '</a>';
                echo '</div>';

                // Definir a variável para true pois um vídeo foi exibido
                $videoDisplayed = true;
            }

            // Verificar se pelo menos um vídeo foi exibido
            if (!$videoDisplayed) {
                echo '<p style="width: 100%; text-align:center; color:#ff0000;">Nenhum vídeo encontrado com o gênero ' . $genre . '</p>';
            }

            ?>
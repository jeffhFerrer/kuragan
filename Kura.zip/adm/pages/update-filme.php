<?php
include_once('conect/conexao.php');

$message = "";

// Função para gerar um nome de arquivo único
function generateUniqueFileName($originalName) {
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $uniqueName = uniqid() . '.' . $extension;
    return $uniqueName;
}

// Selecionar os dados atuais do filme
$filmeId = $_GET["video_id"] ?? null;
$filme = null;
if ($filmeId) {
    $sql = "SELECT * FROM tb_video WHERE video_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $filmeId);
    $stmt->execute();
    $result = $stmt->get_result();
    $filme = $result->fetch_assoc();
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update"])) {
    $alteracoes = [];
    $titulo = $_POST["titulo"];
    $descricao = $_POST["descricao"];
    $genero = $_POST["genero"];
    $classificacao = $_POST["classificacao"];
    $uploadCapaPathBD = $_POST["capa_atual"];
    $uploadPostsPathBD = $_POST["posts_atual"];
    $uploadVideoPathBD = $_POST["video_atual"];

    // Checagem e tratamento para capa
    if (!empty($_FILES["capa"]["name"])) {
        $uploadCapaPathBD = processFileUpload($_FILES["capa"], "../assets/video/capa/", $uploadCapaPathBD);
    }

    // Checagem e tratamento para posts
    if (!empty($_FILES["posts"]["name"])) {
        $uploadPostsPathBD = processFileUpload($_FILES["posts"], "../assets/video/posts/", $uploadPostsPathBD);
    }

    // Checagem e tratamento para vídeo
    if ($_POST["uploadOption"] === "upload" && !empty($_FILES["videoFile"]["name"])) {
        $uploadVideoPathBD = processFileUpload($_FILES["videoFile"], "../uploads/", $uploadVideoPathBD);
    } elseif ($_POST["uploadOption"] === "url") {
        $uploadVideoPathBD = $_POST["videoURL"];
    }

    // Montagem da query de atualização com base nas alterações detectadas
    $sqlSetParts = [];
    $params = [];
    if ($titulo !== $filme['title']) { $sqlSetParts[] = "title = ?"; $params[] = $titulo; }
    if ($descricao !== $filme['descricao']) { $sqlSetParts[] = "descricao = ?"; $params[] = $descricao; }
    if ($genero !== $filme['genero']) { $sqlSetParts[] = "genero = ?"; $params[] = $genero; }
    if ($classificacao !== $filme['classificacao']) { $sqlSetParts[] = "classificacao = ?"; $params[] = $classificacao; }
    if ($uploadCapaPathBD !== $filme['capa']) { $sqlSetParts[] = "capa = ?"; $params[] = $uploadCapaPathBD; }
    if ($uploadPostsPathBD !== $filme['posts']) { $sqlSetParts[] = "posts = ?"; $params[] = $uploadPostsPathBD; }
    if ($uploadVideoPathBD !== $filme['url']) { $sqlSetParts[] = "url = ?"; $params[] = $uploadVideoPathBD; }

    if (!empty($sqlSetParts)) {
        $sql = "UPDATE tb_video SET " . implode(", ", $sqlSetParts) . " WHERE video_id = ?";
        $params[] = $filmeId;
        $types = str_repeat("s", count($params) - 1) . "i"; // Todos os parâmetros são strings exceto o último (ID)
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);

        if ($stmt->execute()) {
            $message = '<div id="ok-sucess">Filme atualizado com sucesso!</div>';
        } else {
            $message = '<div id="no-sucess">Erro ao atualizar o filme. ' . htmlspecialchars($conn->error) . '</div>';
        }

        $stmt->close();
    } else {
        $message = '<div id="ok-sucess">Nenhuma alteração detectada.</div>';
    }
}

function processFileUpload($file, $targetDir, $currentPath) {
    if ($currentPath) {
        @unlink('../' . $currentPath); // Remover arquivo antigo, se houver
    }
    $newFileName = generateUniqueFileName($file["name"]);
    $newFilePath = $targetDir . $newFileName;
    move_uploaded_file($file["tmp_name"], $newFilePath);
    return str_replace("../", "", $newFilePath); // Remover "../" para armazenar o caminho relativo
}
?>

<main class="container my-4">
    
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <input type="radio" name="uploadOption" value="upload" id="uploadOption" checked>
            <label for="uploadOption">Upload de Vídeo</label><br>

            <input type="radio" name="uploadOption" value="url" id="urlOption">
            <label for="urlOption">Link URL do Vídeo</label><br>
        </div>

        <div id="uploadSection">
            <div class="form-group">
                <label for="videoFile">Vídeo:</label>
                <div class="custom-file">
                    <input class="custom-file-input" type="file" name="videoFile" id="videoFile" accept="video/*">
                    <label class="custom-file-label" for="videoFile">Escolha um arquivo de vídeo</label>
                </div>
            </div>
        </div>

        <div id="urlSection" style="display: none;">
            <div class="form-group">
                <label for="videoURL">URL</label>
                <input class="form-control" type="text" name="videoURL" id="videoURL" placeholder="URL do Vídeo">
            </div>
        </div>
        <script>
            const uploadOption = document.getElementById('uploadOption');
            const urlOption = document.getElementById('urlOption');
            const uploadSection = document.getElementById('uploadSection');
            const urlSection = document.getElementById('urlSection');

            uploadOption.addEventListener('change', () => {
                uploadSection.style.display = 'block';
                urlSection.style.display = 'none';
            });

            urlOption.addEventListener('change', () => {
                uploadSection.style.display = 'none';
                urlSection.style.display = 'block';
            });
        </script>
        <div class="form-group">
            <label for="capa">Capa do Vídeo:</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="capa" name="capa" accept="image/*">
                <label class="custom-file-label" for="capa">Escolha um arquivo de imagem</label>
            </div>
        </div>

        <div class="form-group">
            <label for="posts">Post de Apresentação (1110x500):</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="posts" name="posts" accept="image/*">
                <label class="custom-file-label" for="posts">Escolha um arquivo de imagem</label>
            </div>
        </div>

        <div class="form-group">
            <label for="classificacao">Classificação Indicativa:</label>
            <select class="form-control" id="classificacao" name="classificacao">
                <option value="<?php echo $filme['classificacao']; ?>"><?php echo $filme['classificacao']; ?></option>
                <option value="Livre">Livre</option>
                <option value="10+">10+</option>
                <option value="12+">12+</option>
                <option value="14+">14+</option>
                <option value="16+">16+</option>
                <option value="18+">18+</option>
            </select>
        </div>


        <div class="form-group">
            <label for="titulo">Título:</label>
            <input type="text" class="form-control" name="titulo" value="<?php echo $filme['title']; ?>">
        </div>

        <div class="form-group">
            <label for="descricao">Descrição:</label>
            <textarea class="form-control" name="descricao" rows="4"><?php echo $filme['descricao']; ?></textarea>
        </div>

        <div class="form-group">
            <label for="genero">Gênero:</label>
            <input type="text" class="form-control" name="genero" value="<?php echo $filme['genero']; ?>">
        </div>

        <input type="hidden" name="filme_id" value="<?php echo $filme['video_id']; ?>">
        <input type="hidden" name="capa_atual" value="<?php echo $filme['capa']; ?>">
        <input type="hidden" name="posts_atual" value="<?php echo $filme['posts']; ?>">
        <input type="hidden" name="video_atual" value="<?php echo $filme['url']; ?>">

        <button type="submit" class="btn btn-primary" name="update">Enviar Vídeo</button>
    </form>
    <?php echo $message; ?>
</main>
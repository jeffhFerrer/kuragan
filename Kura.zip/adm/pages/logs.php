<?php
include_once('conect/conexao.php');

// Definir o valor padrão para a quantidade de registros por página
$registrosPorPagina = isset($_POST['registros_por_pagina']) ? $_POST['registros_por_pagina'] : 10;

// Filtro de busca
$search = isset($_POST['search']) ? $_POST['search'] : '';

// Consulta para obter os registros de acesso da tabela tb_login_history e relacionar com tb_user
$sql = "SELECT lh.user_id, u.username, u.foto, lh.login_time 
        FROM tb_login_history lh
        INNER JOIN tb_user u ON lh.user_id = u.user_id";

if (!empty($search)) {
    $sql .= " WHERE u.username LIKE '%$search%'";
}

$sql .= " ORDER BY lh.id DESC";

// Adicionar o LIMIT para controlar a quantidade de registros exibidos
if ($registrosPorPagina !== 'all') {
    $sql .= " LIMIT $registrosPorPagina";
}

$result = $conn->query($sql);
?>
<style>

    h1 {
        text-align: center;
        margin-bottom: 20px;
    }

    .table th {
        background-color: #343a40;
        color: #fff;
        font-weight: bold;
        font-size: 16px;
        border: none;
        text-align: center;
    }

    .table td {
        vertical-align: middle;
        text-align: center;
        color: #fff;
    }

    .user-photo {
        width: 50px;
        height: 50px;
        border-radius: 100%;
        object-fit: cover;
    }

    /* Estilo personalizado para o campo de busca */
    .search-container {
        display: flex;
        align-items: center;
        margin-bottom: 20px;
    }

    .search-input {
        flex: 1;
        padding: 10px;
        color: #fff;
        font-weight: 700;
        border: 1px solid #ccc;
        border-top-left-radius: 5px;
        border-bottom-left-radius: 5px;
        background: transparent;
        outline: none;
    }

    .search-button {
        background-color: #007bff;
        border: none;
        color: #fff;
        padding: 10px 15px;
        border: 1px solid #007bff;
        border-top-right-radius: 5px;
        border-bottom-right-radius: 5px;
        cursor: pointer;
    }

    #registros_por_pagina {
        background: #000924;
        outline: none;
        color: #fff;
        font-weight: 700;
    }
</style>
<form action="" method="post">
    <div class="search-container">
        <input type="text" class="search-input" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Buscar por Nome de Usuário ou Data de Acesso">
        <button type="submit" class="search-button"><i class="fas fa-search"></i></button>
    </div>
</form>

<div class="form-group">
    <form action="" method="post">
        <label for="registros_por_pagina">Quantidade de Registros por Página:</label>
        <select class="form-control" id="registros_por_pagina" name="registros_por_pagina" onchange="this.form.submit()">
        <option value="5" <?php if ($registrosPorPagina == 5)
                    echo 'selected'; ?>>
                    5
                </option>
                <option value="10" <?php if ($registrosPorPagina == 10)
                    echo 'selected'; ?>>
                    10
                </option>
                <option value="25" <?php if ($registrosPorPagina == 25)
                    echo 'selected'; ?>>
                    25
                </option>
                <option value="50" <?php if ($registrosPorPagina == 50)
                    echo 'selected'; ?>>
                    50
                </option>
                <option value="all" <?php if ($registrosPorPagina == 'all')
                    echo 'selected'; ?>>
                    Todos
                </option>
        </select>
        <!-- Mantenha a pesquisa atual ao alterar a quantidade de registros por página -->
        <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
    </form>
</div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th> <!-- Coluna para a numeração -->
                <th>Imagem</th>
                <th>Nome do Usuário</th>
                <th>Data e Hora do Acesso</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $contador = 1; // Inicializar a variável contador
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $contador . '</td>'; // Exibir o número
                    echo '<td><img src="../assets/user/' . $row["foto"] . '" alt="Foto do Usuário" class="user-photo"></td>';
                    echo '<td>' . $row["username"] . '</td>';
                    echo '<td>' . date('d/m/Y H:i:s', strtotime($row['login_time'])) . '</td>';
                    echo '</tr>';
                    $contador++; // Incrementar o contador
                }
            } else {
                echo '<tr><td colspan="4">Nenhum registro de acesso encontrado.</td></tr>';
            }
            ?>
        </tbody>
    </table>
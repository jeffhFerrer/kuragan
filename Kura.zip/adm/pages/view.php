<style>
    .main{
        padding: 5px;
    }
    .frame-view{
        width: 100%;
        min-height: calc(100vh - 100px);
    }
</style>
<iframe class="frame-view" src="https://kuragan.000webhostapp.com/" frameborder="0"></iframe>
<?php
include_once('conect/conexao.php');
// Verificar se o tipo de usuário não está definido ou é diferente de 2 ou 3
$user_id = $_SESSION['user_id'];

// Consulta para buscar os dados do usuário
$sql_user = "SELECT * FROM tb_user WHERE user_id = $user_id";
$result_user = mysqli_query($conn, $sql_user);

// Verificar se a consulta foi bem-sucedida e obter os dados do usuário
if ($result_user) {
    $row_user = mysqli_fetch_assoc($result_user);

    if (!isset($row_user['tipo_user']) || ($row_user['tipo_user'] != 2 && $row_user['tipo_user'] != 3)) {
        // Redirecionar o usuário para a página de índice
        echo '<script>
            setTimeout(function() {
                window.location.href = "index.php";
            }, 0000); 
        </script>';
        exit();
    }
} else {
    // Lida com erros na consulta ao banco de dados, se necessário
    echo "Erro na consulta ao banco de dados";
}

?>
<style>
    .container {
        margin-top: 50px;
    }

    h1 {
        text-align: center;
        margin-bottom: 20px;
    }

    .table th {
        background-color: #343a40;
        color: #fff;
        font-weight: bold;
        font-size: 16px;
        border: none;
        text-align: center;
    }

    .table td {
        vertical-align: middle;
        text-align: center;
        color: #fff;
    }

    .user-photo {
        width: 50px;
        height: 50px;
        border-radius: 100%;
        object-fit: cover;
    }

    /* Estilo personalizado para o campo de busca */
    .search-container {
        display: flex;
        align-items: center;
        margin-bottom: 20px;
    }

    .search-input {
        flex: 1;
        padding: 10px;
        color: #fff;
        font-weight: 700;
        border: 1px solid #ccc;
        border-top-left-radius: 5px;
        border-bottom-left-radius: 5px;
        background: transparent;
        outline: none;
    }

    .search-button {
        background-color: #007bff;
        border: none;
        color: #fff;
        padding: 10px 15px;
        border: 1px solid #007bff;
        border-top-right-radius: 5px;
        border-bottom-right-radius: 5px;
        cursor: pointer;
    }

    #registros_por_pagina {
        background: transparent;
        outline: none;
        color: #fff;
        font-weight: 700;
    }

    .table td .dropdown-menu {
        position: absolute;
        float: center;
        display: none;
        min-width: 100%;
        padding: 5px;
        margin: 0;
        font-size: 1rem;
        color: #212529;
        text-align: center;
        list-style: none;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid rgba(0, 0, 0, .15);
        border-radius: .25rem;
    }

    .table td:hover .dropdown-menu {
        display: block;
        margin-top: 10px;
    }

    .table td .dropdown-item {
        display: block;
        width: 100%;
        padding: 10px;
        clear: both;
        font-weight: 400;
        color: #212529;
        text-align: center;
        white-space: nowrap;
        background-color: transparent;
        border: 0;
    }

    .counter {
        display: flex;
        justify-content: space-between;
        border: 1px solid #fff;
        padding: 10px;
        border-radius: 5px;
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
    }

    .counter-item {
        text-align: center;
        font-weight: 900;
    }

    .counter-label {
        font-size: 18px;
        color: #999;
    }

    .counter-value {
        font-size: 24px;
        color: #007bff;
    }
</style>

<?php
// Consulta SQL para contar todos os registros
$sqlTotal = "SELECT COUNT(*) as total FROM mensagens_suporte";
$resultTotal = $conn->query($sqlTotal);
$rowTotal = $resultTotal->fetch_assoc();
$totalRegistros = $rowTotal['total'];

// Consulta SQL para contar os registros concluídos
$sqlConcluidos = "SELECT COUNT(*) as concluidos FROM mensagens_suporte WHERE status = 'concluida'";
$resultConcluidos = $conn->query($sqlConcluidos);
$rowConcluidos = $resultConcluidos->fetch_assoc();
$totalConcluidos = $rowConcluidos['concluidos'];

// Calcula o número de registros que faltam
$faltamRegistros = $totalRegistros - $totalConcluidos;
?>

<div class="container">
    <div class="counter">
        <div class="counter-item">
            <p class="counter-label">Total de Chamadas</p>
            <p class="counter-value">
                <?php echo $totalRegistros; ?>
            </p>
        </div>
        <div class="counter-item">
            <p class="counter-label">Chamadas Concluídas</p>
            <p class="counter-value">
                <?php echo $totalConcluidos; ?>
            </p>
        </div>
        <div class="counter-item">
            <p class="counter-label">Chamadas que Faltam</p>
            <p class="counter-value">
                <?php echo $faltamRegistros; ?>
            </p>
        </div>
    </div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>USUÁRIO</th>
                <th>ASSUNTO</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Consulta SQL para obter as mensagens pendentes
            $sql = "SELECT id, nome, email, assunto FROM mensagens_suporte WHERE status = 'pendente'";
            $result = $conn->query($sql);
            $contador = 1; // Inicializar o contador
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $contador . '</td>';
                    echo '<td>' . $row['nome'] . '</td>';
                    echo '<td>' . $row["assunto"] . '</td>';
                    echo '<td>';
                    echo '<div class="dropdown">';
                    echo '<button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Ações</button>';
                    echo '<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">';
                    echo '<a class="dropdown-item" href="index.php?acao=suporte_det&id=' . $row['id'] . '" onclick="return confirm(\'deseja visualizar esta mensagem?\');">visualizar</a>';
                    echo '<a class="dropdown-item" href="index.php?acao=suporte_con&id=' . $row['id'] . '" onclick="return confirm(\'deseja marcar como concluida esta mensagem?\');">concluido</a>';
                    echo '</div>';
                    echo '</div>';
                    echo '</td>';
                    echo '</tr>';
                    $contador++;
                }
            } else {
                echo '<tr><td colspan="4">Nenhuma chamada encontrada.</td></tr>';
            }
            ?>
        </tbody>
    </table>
</div>
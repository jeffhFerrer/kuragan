<?php
include_once('conect/conexao.php');
session_start();

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Usando consultas preparadas para evitar SQL Injection
    $sql_user = "SELECT * FROM tb_user WHERE user_id = ?";
    $stmt = $conn->prepare($sql_user);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result_user = $stmt->get_result();

    if ($result_user && $result_user->num_rows > 0) {
        $row_user = $result_user->fetch_assoc();

        // Verificar se o tipo de usuário não está definido ou é diferente de 2 ou 3
        if (!isset($row_user['tipo_user']) || $row_user['tipo_user'] != 3) {
            // Redirecionar o usuário para ../index.php se não tiver permissão
            header('Location: ../index.php');
            exit();
        }
    } else {
        // Usuário não encontrado, redirecionar para ../index.php
        header('Location: ../index.php');
        exit();
    }
} else {
    // Sessão não definida (usuário não está logado), redirecionar para ../index.php
    header('Location: ../index.php');
    exit();
}
?>



<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="../icon.png" type="image/x-icon">
    </head>

<body>
    <div class="header expanded">
        <button class="toggle-btn" onclick="toggleSidebar()">☰</button>
        <a class="log" href="../logout.php">sair</a>
    </div>
    <div id="sidebar" class="sidebar">
        <a class="nav-link" href="index.php">HOME</a>
        <a class="nav-link" href="index.php?acao=view">Visualizar</a>
        <a class="nav-link" href="index.php?acao=type_user">Tipo Usuário</a>
        <a class="nav-link" href="index.php?acao=upload">Upload</a>
        <a href="index.php?acao=acao-videos">Ações</a>
        <a href="index.php?acao=notification">Notificação</a>
        <a class="nav-link" href="index.php?acao=suporte_reg">Suporte</a>
        <a class="nav-link" href="index.php?acao=logs">Acessos</a>
    </div>
    <div id="main" class="main expanded">
        <script>
            function toggleSidebar() {
                var sidebar = document.getElementById("sidebar");
                var main = document.getElementById("main");
                var header = document.querySelector(".header");

                sidebar.classList.toggle("collapsed");
                main.classList.toggle("expanded");
                header.classList.toggle("expanded");

            }
        </script>
    